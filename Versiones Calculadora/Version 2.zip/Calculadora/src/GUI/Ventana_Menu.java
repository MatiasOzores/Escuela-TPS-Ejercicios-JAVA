package GUI;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;



public class Ventana_Menu extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField casilla_1_ent;
	private JTextField casilla_2_ent;
	private JTextField casilla_3_ent;
	private JTextField casilla_4_ent;
	private JTextField casilla_5_ent;
	private JTextField casilla_6_ent;
	private JTextField casilla_7_ent;
	private JTextField casilla_8_ent;
	private JTextField casilla_9_ent;
	private JTextField casilla_1_sal;
	private JTextField casilla_2_sal;
	private JTextField casilla_3_sal;
	private JTextField casilla_4_sal;
	private JTextField casilla_5_sal;
	private JTextField casilla_6_sal;
	private JTextField casilla_7_sal;
	private JTextField casilla_8_sal;
	private JTextField casilla_9_sal;
	private JTextField num_escalar;

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana_Menu frame = new Ventana_Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		
	}

	/**
	 * Create the frame.
	 */
	public Ventana_Menu() {
		Color miColorPrin = new Color(26, 27, 40);
		Color miColorSec = new Color(87, 116, 250);
		Color letrasColor = new Color(255,255,255);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 650);
		setResizable(false);
		setTitle("Matrices | Ozores Matías y Amodeo Luca");
		contentPane = new JPanel();
		contentPane.setBackground(miColorPrin);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel principal = new JPanel();
		principal.setBackground(miColorPrin);
		principal.setBounds(23, 215, 834, 373);
		contentPane.add(principal);
		principal.setLayout(null);
		
		JPanel mult_escalar = new RoundedPanel(15,miColorSec);
		mult_escalar.setBounds(10, 300, 260, 47);
		principal.add(mult_escalar);
		mult_escalar.setOpaque(false);
		mult_escalar.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel calc_escalar = new JLabel("Calcular escalar");
		calc_escalar.setForeground(letrasColor);
		calc_escalar.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		calc_escalar.setAlignmentX(Component.CENTER_ALIGNMENT);
		calc_escalar.setHorizontalAlignment(SwingConstants.CENTER);
		calc_escalar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mult_escalar.add(calc_escalar);
		
		JPanel determinante = new RoundedPanel(15,miColorSec);
		determinante.setBackground(miColorSec);
		determinante.setBounds(280, 300, 274, 47);
		determinante.setOpaque(false);
		principal.add(determinante);
		determinante.setLayout(new GridLayout(1, 0, 0, 0));
		
		JLabel calc_determinante = new JLabel("Calcular determinante");
		calc_determinante.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		calc_determinante.setForeground(letrasColor);
		calc_determinante.setHorizontalAlignment(SwingConstants.CENTER);
		calc_determinante.setAlignmentX(0.5f);
		calc_determinante.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		determinante.add(calc_determinante);
		
		JPanel inversa = new RoundedPanel(15,miColorSec);
		inversa.setBackground(miColorSec);
		inversa.setBounds(564, 300, 260, 47);
		inversa.setOpaque(false);
		principal.add(inversa);
		inversa.setLayout(new GridLayout(1, 0, 0, 0));
		
		JLabel calc_inversa = new JLabel("Calcular inversa");
		calc_inversa.setForeground(letrasColor);
		calc_inversa.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		calc_inversa.setHorizontalAlignment(SwingConstants.CENTER);
		calc_inversa.setAlignmentX(0.5f);
		calc_inversa.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		inversa.add(calc_inversa);
		
		JPanel matrices = new JPanel();
		matrices.setBackground(new Color(0, 64, 128));
		matrices.setBounds(10, 11, 814, 264);
		matrices.setOpaque(false);
		principal.add(matrices);
		matrices.setLayout(null);
		
		JPanel entrada = new JPanel();
		entrada.setBackground(new Color(128, 128, 192));
		entrada.setOpaque(false);
		entrada.setBounds(0, 0, 370, 264);
		matrices.add(entrada);
		entrada.setLayout(null);
		
		casilla_1_ent = new JTextField();
		casilla_1_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_1_ent.getText();

		        if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		casilla_1_ent.setBackground(new Color(30, 36, 53));
		casilla_1_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_1_ent.setForeground(new Color(254, 254, 254));
		casilla_1_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_1_ent.setBounds(34, 11, 70, 70);
		entrada.add(casilla_1_ent);
		casilla_1_ent.setColumns(10);
		casilla_1_ent.setBorder(BorderFactory.createEmptyBorder());
		
		
		
		casilla_2_ent = new JTextField();
		casilla_2_ent.setBackground(new Color(30, 36, 53));
		casilla_2_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_2_ent.setForeground(new Color(254, 254, 254));
		casilla_2_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_2_ent.setColumns(10);
		casilla_2_ent.setBounds(150, 11, 70, 70);
		casilla_2_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_2_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_2_ent.getText();

		        if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_2_ent);
		
		casilla_3_ent = new JTextField();
		casilla_3_ent.setBackground(new Color(30, 36, 53));
		casilla_3_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_3_ent.setForeground(new Color(254, 254, 254));
		casilla_3_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_3_ent.setColumns(10);
		casilla_3_ent.setBounds(266, 11, 70, 70);
		casilla_3_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_3_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_3_ent.getText();

		        if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_3_ent);
		
		casilla_4_ent = new JTextField();
		casilla_4_ent.setBackground(new Color(30, 36, 53));
		casilla_4_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_4_ent.setForeground(new Color(254, 254, 254));
		casilla_4_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_4_ent.setColumns(10);
		casilla_4_ent.setBounds(34, 98, 70, 70);
		casilla_4_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_4_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_4_ent.getText();

		        if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_4_ent);
		
		casilla_5_ent = new JTextField();
		casilla_5_ent.setBackground(new Color(30, 36, 53));
		casilla_5_ent.setForeground(new Color(254, 254, 254));
		casilla_5_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_5_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_5_ent.setColumns(10);
		casilla_5_ent.setBounds(150, 98, 70, 70);
		casilla_5_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_5_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_5_ent.getText();

		        if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_5_ent);
		
		casilla_6_ent = new JTextField();
		casilla_6_ent.setBackground(new Color(30, 36, 53));
		casilla_6_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_6_ent.setForeground(new Color(254, 254, 254));
		casilla_6_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_6_ent.setColumns(10);
		casilla_6_ent.setBounds(266, 98, 70, 70);
		casilla_6_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_6_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_6_ent.getText();

		        if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_6_ent);
		
		casilla_7_ent = new JTextField();
		casilla_7_ent.setBackground(new Color(30, 36, 53));
		casilla_7_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_7_ent.setForeground(new Color(254, 254, 254));
		casilla_7_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_7_ent.setColumns(10);
		casilla_7_ent.setBounds(34, 186, 70, 70);
		casilla_7_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_7_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_7_ent.getText();

		        if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_7_ent);
		
		casilla_8_ent = new JTextField();
		casilla_8_ent.setBackground(new Color(30, 36, 53));
		casilla_8_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_8_ent.setForeground(new Color(254, 254, 254));
		casilla_8_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_8_ent.setColumns(10);
		casilla_8_ent.setBounds(150, 186, 70, 70);
		casilla_8_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_8_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_8_ent.getText();

		        if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_8_ent);
		
		casilla_9_ent = new JTextField();
		casilla_9_ent.setBackground(new Color(30, 36, 53));
		casilla_9_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_9_ent.setForeground(new Color(254, 254, 254));
		casilla_9_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_9_ent.setColumns(10);
		casilla_9_ent.setBounds(266, 186, 70, 70);
		casilla_9_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_9_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_9_ent.getText();

		        if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_9_ent);
		
		JLabel corchete_izq = new JLabel("");
		corchete_izq.setVerticalAlignment(SwingConstants.TOP);
		corchete_izq.setHorizontalAlignment(SwingConstants.LEFT);
		corchete_izq.setIcon(new ImageIcon(getClass().getResource("/GUI/imagenes/CorcheteIzq.png")));
		corchete_izq.setBounds(0, 0, 29, 264);
		entrada.add(corchete_izq);
		
		JLabel corchete_der = new JLabel("");
		corchete_der.setVerticalAlignment(SwingConstants.TOP);
		corchete_der.setHorizontalAlignment(SwingConstants.RIGHT);
		corchete_der.setIcon(new ImageIcon(getClass().getResource("/GUI/imagenes/CorcheteDer.png")));
		corchete_der.setBounds(341, 0, 29, 264);
		entrada.add(corchete_der);
		
		JPanel salida = new JPanel();
		salida.setBorder(null);
		salida.setBackground(new Color(128, 128, 192));
		salida.setBounds(444, 0, 370, 264);
		salida.setOpaque(false);
		matrices.add(salida);
		salida.setLayout(null);
		
		JLabel corchete_izq_1 = new JLabel("");
		corchete_izq_1.setVerticalAlignment(SwingConstants.TOP);
		corchete_izq_1.setHorizontalAlignment(SwingConstants.LEFT);
		corchete_izq_1.setIcon(new ImageIcon(getClass().getResource("/GUI/imagenes/CorcheteIzq.png")));
		corchete_izq_1.setBounds(0, 0, 29, 264);
		salida.add(corchete_izq_1);
		
		JLabel corchete_der_1 = new JLabel("");
		corchete_der_1.setVerticalAlignment(SwingConstants.TOP);
		corchete_der_1.setHorizontalAlignment(SwingConstants.RIGHT);
		corchete_der_1.setIcon(new ImageIcon(getClass().getResource("/GUI/imagenes/CorcheteDer.png")));
		corchete_der_1.setBounds(341, 0, 29, 264);
		salida.add(corchete_der_1);
		
		casilla_1_sal = new JTextField();
		casilla_1_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_1_sal.setForeground(new Color(30, 36, 53));
		casilla_1_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_1_sal.setColumns(10);
		casilla_1_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_1_sal.setBounds(34, 11, 70, 70);
		casilla_1_sal.setEditable(false); 
		casilla_1_sal.setFocusable(false);
		salida.add(casilla_1_sal);
		
		casilla_2_sal = new JTextField();
		casilla_2_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_2_sal.setForeground(new Color(30, 36, 53));
		casilla_2_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_2_sal.setColumns(10);
		casilla_2_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_2_sal.setBounds(150, 11, 70, 70);
		casilla_2_sal.setEditable(false); 
		casilla_2_sal.setFocusable(false);
		salida.add(casilla_2_sal);
		
		casilla_3_sal = new JTextField();
		casilla_3_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_3_sal.setForeground(new Color(30, 36, 53));
		casilla_3_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_3_sal.setColumns(10);
		casilla_3_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_3_sal.setBounds(266, 11, 70, 70);
		casilla_3_sal.setEditable(false); 
		casilla_3_sal.setFocusable(false);
		salida.add(casilla_3_sal);
		
		casilla_4_sal = new JTextField();
		casilla_4_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_4_sal.setForeground(new Color(30, 36, 53));
		casilla_4_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_4_sal.setColumns(10);
		casilla_4_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_4_sal.setBounds(34, 98, 70, 70);
		casilla_4_sal.setEditable(false); 
		casilla_4_sal.setFocusable(false);
		salida.add(casilla_4_sal);
		
		casilla_5_sal = new JTextField();
		casilla_5_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_5_sal.setForeground(new Color(30, 36, 53));
		casilla_5_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_5_sal.setColumns(10);
		casilla_5_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_5_sal.setBounds(150, 98, 70, 70);
		casilla_5_sal.setEditable(false); 
		casilla_5_sal.setFocusable(false);
		salida.add(casilla_5_sal);
		
		casilla_6_sal = new JTextField();
		casilla_6_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_6_sal.setForeground(new Color(30, 36, 53));
		casilla_6_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_6_sal.setColumns(10);
		casilla_6_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_6_sal.setBounds(266, 98, 70, 70);
		casilla_6_sal.setEditable(false); 
		casilla_6_sal.setFocusable(false);
		salida.add(casilla_6_sal);
		
		casilla_7_sal = new JTextField();
		casilla_7_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_7_sal.setForeground(new Color(30, 36, 53));
		casilla_7_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_7_sal.setColumns(10);
		casilla_7_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_7_sal.setBounds(34, 186, 70, 70);
		casilla_7_sal.setEditable(false); 
		casilla_7_sal.setFocusable(false);
		salida.add(casilla_7_sal);
		
		casilla_8_sal = new JTextField();
		casilla_8_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_8_sal.setForeground(new Color(30, 36, 53));
		casilla_8_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_8_sal.setColumns(10);
		casilla_8_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_8_sal.setBounds(150, 186, 70, 70);
		casilla_8_sal.setEditable(false); 
		casilla_8_sal.setFocusable(false);
		salida.add(casilla_8_sal);
		
		casilla_9_sal = new JTextField();
		casilla_9_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_9_sal.setForeground(new Color(30, 36, 53));
		casilla_9_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_9_sal.setColumns(10);
		casilla_9_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_9_sal.setBounds(266, 186, 70, 70);
		casilla_9_sal.setEditable(false); 
		casilla_9_sal.setFocusable(false);
		salida.add(casilla_9_sal);

		
		JLabel igual = new JLabel("=");
		igual.setForeground(new Color(255, 255, 255));
		igual.setFont(new Font("Tahoma", Font.PLAIN, 20));
		igual.setHorizontalAlignment(SwingConstants.CENTER);
		igual.setBounds(368, 98, 80, 70);
		matrices.add(igual);
		
		JLabel igual_1 = new JLabel("+/-");
		igual_1.setHorizontalAlignment(SwingConstants.CENTER);
		igual_1.setForeground(Color.WHITE);
		igual_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		igual_1.setBounds(368, 17, 80, 70);
		matrices.add(igual_1);
		
		num_escalar = new JTextField();
		num_escalar.setHorizontalAlignment(SwingConstants.CENTER);
		num_escalar.setForeground(new Color(254, 254, 254));
		num_escalar.setFont(new Font("Tahoma", Font.BOLD, 18));
		num_escalar.setColumns(10);
		num_escalar.setBorder(BorderFactory.createEmptyBorder());
		num_escalar.setBackground(new Color(30, 36, 53));
		num_escalar.setBounds(383, 203, 50, 50);
		matrices.add(num_escalar);
		
		JLabel lblNewLabel = new JLabel("Escalar");
		lblNewLabel.setFont(new Font("Roboto", Font.PLAIN, 12));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(388, 179, 46, 14);
		matrices.add(lblNewLabel);
		
		JPanel menu_matrices = new JPanel();
		menu_matrices.setBackground(miColorPrin);
		menu_matrices.setBounds(23, 125, 834, 89);
		contentPane.add(menu_matrices);
		menu_matrices.setLayout(null);
		
		JPanel ingresar_una_matriz = new RoundedPanel(15,miColorSec);
		ingresar_una_matriz.setBackground(miColorSec);
		ingresar_una_matriz.setBounds(10, 11, 390, 67);
		ingresar_una_matriz.setOpaque(false);
		menu_matrices.add(ingresar_una_matriz);
		ingresar_una_matriz.setLayout(new GridLayout(1, 0, 0, 0));

		
		JLabel ingreso_una = new JLabel("Ingresar una matriz");
		ingreso_una.setFont(new Font("Roboto Medium", Font.PLAIN, 18));
		ingreso_una.setForeground(letrasColor);
		ingreso_una.setHorizontalAlignment(SwingConstants.CENTER);
		ingreso_una.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		ingresar_una_matriz.add(ingreso_una);
		
		JPanel ingresar_dos_matrices = new RoundedPanel(15, new Color(30, 36, 53));
		ingresar_dos_matrices.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				ingresar_dos_matrices.setBackground(new Color(48, 58, 85));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				ingresar_dos_matrices.setBackground(new Color(30, 36, 53));
			}
		});
		ingresar_dos_matrices.setOpaque(false);
		ingresar_dos_matrices.setBackground(new Color(30, 36, 53));
		ingresar_dos_matrices.setBounds(434, 11, 390, 67);
		menu_matrices.add(ingresar_dos_matrices);
		ingresar_dos_matrices.setLayout(new GridLayout(1, 0, 0, 0));
		
		JLabel ingreso_dos = new JLabel("Ingresar dos matrices");
		ingreso_dos.setHorizontalAlignment(SwingConstants.CENTER);
		ingreso_dos.setForeground(Color.WHITE);
		ingreso_dos.setFont(new Font("Roboto Medium", Font.PLAIN, 18));
		ingreso_dos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		ingresar_dos_matrices.add(ingreso_dos);
		
		JPanel menu_general = new JPanel();
		menu_general.setBackground(miColorPrin);
		menu_general.setBounds(23, 34, 834, 80);
		contentPane.add(menu_general);
		menu_general.setLayout(null);
		
		JPanel aritmeticas = new JPanel();
		
		aritmeticas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				aritmeticas.setBackground(new Color(155, 172, 254));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				aritmeticas.setBackground(new Color(255, 255, 255));
			}
		});
		aritmeticas.setBackground(new Color(255, 255, 255));
		aritmeticas.setBounds(10, 11, 185, 58);
		menu_general.add(aritmeticas);
		aritmeticas.setLayout(new GridLayout(0, 1, 0, 0));
		
		
		
		JLabel texto_aritmeticas = new JLabel("ESTANDAR");
		texto_aritmeticas.setFont(new Font("Roboto Medium", Font.PLAIN, 14));
		texto_aritmeticas.setForeground(new Color(30, 36, 53));
		texto_aritmeticas.setHorizontalAlignment(SwingConstants.CENTER);
		texto_aritmeticas.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		aritmeticas.add(texto_aritmeticas);
		
		
		JPanel vectores = new JPanel();
		vectores.setBackground(Color.WHITE);
		vectores.setBounds(221, 11, 185, 58);
		menu_general.add(vectores);
		vectores.setLayout(new GridLayout(1, 0, 0, 0));
		
		vectores.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				vectores.setBackground(new Color(155, 172, 254));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				vectores.setBackground(new Color(255, 255, 255));
			}
		});
		
		JLabel texto_vectores = new JLabel("VECTORES");
		texto_vectores.setHorizontalAlignment(SwingConstants.CENTER);
		texto_vectores.setForeground(new Color(30, 36, 53));
		texto_vectores.setFont(new Font("Roboto Medium", Font.PLAIN, 14));
		texto_vectores.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		vectores.add(texto_vectores);
		
		JPanel matrices_operaciones = new JPanel();
		matrices_operaciones.setBackground(miColorSec);
		matrices_operaciones.setBounds(432, 11, 185, 58);
		menu_general.add(matrices_operaciones);
		matrices_operaciones.setLayout(new GridLayout(1, 0, 0, 0));
		
		JLabel texto_matrices = new JLabel("MATRICES");
		texto_matrices.setBackground(miColorSec);
		texto_matrices.setHorizontalAlignment(SwingConstants.CENTER);
		texto_matrices.setForeground(letrasColor);
		texto_matrices.setFont(new Font("Roboto Medium", Font.PLAIN, 14));
		texto_matrices.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		matrices_operaciones.add(texto_matrices);
		
		JPanel ecuaciones = new JPanel();
		ecuaciones.setBackground(Color.WHITE);
		ecuaciones.setBounds(639, 11, 185, 58);
		menu_general.add(ecuaciones);
		ecuaciones.setLayout(new GridLayout(1, 0, 0, 0));
		
		ecuaciones.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				ecuaciones.setBackground(new Color(155, 172, 254));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				ecuaciones.setBackground(new Color(255, 255, 255));
			}
		});
		
		JLabel texto_ecuaciones = new JLabel("ECUACIONES");
		texto_ecuaciones.setHorizontalAlignment(SwingConstants.CENTER);
		texto_ecuaciones.setForeground(new Color(30, 36, 53));
		texto_ecuaciones.setFont(new Font("Roboto Medium", Font.PLAIN, 14));
		texto_ecuaciones.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		ecuaciones.add(texto_ecuaciones);
		
		
		
		calc_escalar.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseClicked(java.awt.event.MouseEvent evt) {
		        if (areAllFieldsFilled()) {
		        	String valor1 = casilla_1_ent.getText();
		        	String valor2 = casilla_2_ent.getText();
		        	String valor3 = casilla_3_ent.getText();
		        	String valor4 = casilla_4_ent.getText();
		        	String valor5 = casilla_5_ent.getText();
		        	String valor6 = casilla_6_ent.getText();
		        	String valor7 = casilla_7_ent.getText();
		        	String valor8 = casilla_8_ent.getText();
		        	String valor9 = casilla_9_ent.getText();
		        	String escalar_num = num_escalar.getText();
		        	
		        	int intValor1 = Integer.parseInt(valor1);
		        	int intValor2 = Integer.parseInt(valor2);
		        	int intValor3 = Integer.parseInt(valor3);
		        	int intValor4 = Integer.parseInt(valor4);
		        	int intValor5 = Integer.parseInt(valor5);
		        	int intValor6 = Integer.parseInt(valor6);
		        	int intValor7 = Integer.parseInt(valor7);
		        	int intValor8 = Integer.parseInt(valor8);
		        	int intValor9 = Integer.parseInt(valor9);
		        	int numEscalar = Integer.parseInt(escalar_num);



		        	int[][] resultado = new int[3][3];
		        	resultado[0][0] = intValor1 * numEscalar;
		        	resultado[0][1] = intValor2 * numEscalar;
		        	resultado[0][2] = intValor3 * numEscalar;

		        	resultado[1][0] = intValor4 * numEscalar;
		        	resultado[1][1] = intValor5 * numEscalar;
		        	resultado[1][2] = intValor6 * numEscalar;

		        	resultado[2][0] = intValor7 * numEscalar;
		        	resultado[2][1] = intValor8 * numEscalar;
		        	resultado[2][2] = intValor9 * numEscalar;

		        	
		    		casilla_1_sal.setBounds(34, 11, 70, 70);
		            casilla_2_sal.setVisible(true);
		            casilla_3_sal.setVisible(true);
		            casilla_4_sal.setVisible(true);
		            casilla_5_sal.setVisible(true);
		            casilla_6_sal.setVisible(true);
		            casilla_7_sal.setVisible(true);
		            casilla_8_sal.setVisible(true);
		            casilla_9_sal.setVisible(true);
		            
		            casilla_1_sal.setText(String.valueOf(resultado[0][0]));
		            casilla_2_sal.setText(String.valueOf(resultado[0][1]));
		            casilla_3_sal.setText(String.valueOf(resultado[0][2]));
		            casilla_4_sal.setText(String.valueOf(resultado[1][0]));
		            casilla_5_sal.setText(String.valueOf(resultado[1][1]));
		            casilla_6_sal.setText(String.valueOf(resultado[1][2]));
		            casilla_7_sal.setText(String.valueOf(resultado[2][0]));
		            casilla_8_sal.setText(String.valueOf(resultado[2][1]));
		            casilla_9_sal.setText(String.valueOf(resultado[2][2]));

		        } else {
		            JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");
		        }
		    }

		    private boolean areAllFieldsFilled() {
		        return !num_escalar.getText().isEmpty() &&
		        	   !casilla_1_ent.getText().isEmpty() && 
		               !casilla_2_ent.getText().isEmpty() && 
		               !casilla_3_ent.getText().isEmpty() && 
		               !casilla_4_ent.getText().isEmpty() && 
		               !casilla_5_ent.getText().isEmpty() && 
		               !casilla_6_ent.getText().isEmpty() && 
		               !casilla_7_ent.getText().isEmpty() && 
		               !casilla_8_ent.getText().isEmpty() && 
		               !casilla_9_ent.getText().isEmpty();
		    }

		    @Override
		    public void mouseEntered(MouseEvent e) {
		        calc_escalar.setForeground(new Color(205, 205, 205));
		    }

		    @Override
		    public void mouseExited(MouseEvent e) {
		        calc_escalar.setForeground(letrasColor);    
		    }
		});

		
		calc_determinante.addMouseListener(new java.awt.event.MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				calc_determinante.setForeground(new Color(205, 205, 205));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				calc_determinante.setForeground(letrasColor);	
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				if (areAllFieldsFilled()) {
		        	String valor1 = casilla_1_ent.getText();
		        	String valor2 = casilla_2_ent.getText();
		        	String valor3 = casilla_3_ent.getText();
		        	String valor4 = casilla_4_ent.getText();
		        	String valor5 = casilla_5_ent.getText();
		        	String valor6 = casilla_6_ent.getText();
		        	String valor7 = casilla_7_ent.getText();
		        	String valor8 = casilla_8_ent.getText();
		        	String valor9 = casilla_9_ent.getText();

		        	int intValor1 = Integer.parseInt(valor1);
		        	int intValor2 = Integer.parseInt(valor2);
		        	int intValor3 = Integer.parseInt(valor3);
		        	int intValor4 = Integer.parseInt(valor4);
		        	int intValor5 = Integer.parseInt(valor5);
		        	int intValor6 = Integer.parseInt(valor6);
		        	int intValor7 = Integer.parseInt(valor7);
		        	int intValor8 = Integer.parseInt(valor8);
		        	int intValor9 = Integer.parseInt(valor9);

		        	/* Lógica del cálculo del producto escalar */
		        	int diagonal_principal_uno = intValor1 * intValor5 * intValor9;
		        	int diagonal_principal_dos = intValor4 * intValor8 * intValor3;
		        	int diagonal_principal_tres = intValor7 * intValor2 * intValor6;

		        	int diagonal_secundaria_uno = intValor3 * intValor5 * intValor7;
		        	int diagonal_secundaria_dos = intValor6 * intValor8 * intValor1;
		        	int diagonal_secundaria_tres = intValor9 * intValor2 * intValor4;

		            int resultado = (diagonal_principal_uno + diagonal_principal_dos + diagonal_principal_tres) - (diagonal_secundaria_uno + diagonal_secundaria_dos + diagonal_secundaria_tres);
		            casilla_1_sal.setText(Integer.toString(resultado));
		            casilla_2_sal.setVisible(false);
		            casilla_3_sal.setVisible(false);
		            casilla_4_sal.setVisible(false);
		            casilla_5_sal.setVisible(false);
		            casilla_6_sal.setVisible(false);
		            casilla_7_sal.setVisible(false);
		            casilla_8_sal.setVisible(false);
		            casilla_9_sal.setVisible(false);
		            casilla_1_sal.setBounds(131, 80, 100, 100);
		        }else {
		            JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");
		        }
			}
			
		    private boolean areAllFieldsFilled() {
		        return !casilla_1_ent.getText().isEmpty() && 
		               !casilla_2_ent.getText().isEmpty() && 
		               !casilla_3_ent.getText().isEmpty() && 
		               !casilla_4_ent.getText().isEmpty() && 
		               !casilla_5_ent.getText().isEmpty() && 
		               !casilla_6_ent.getText().isEmpty() && 
		               !casilla_7_ent.getText().isEmpty() && 
		               !casilla_8_ent.getText().isEmpty() && 
		               !casilla_9_ent.getText().isEmpty();
		    }
		});
		

		calc_inversa.addMouseListener(new java.awt.event.MouseAdapter() {
		    @Override
		    public void mouseEntered(MouseEvent e) {
		        calc_inversa.setForeground(new Color(205, 205, 205));
		    }
		    @Override
		    public void mouseExited(MouseEvent e) {
		        calc_inversa.setForeground(letrasColor);    
		    }
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        
		        if (areAllFieldsFilled()) {
		            String valor1 = casilla_1_ent.getText();
		            String valor2 = casilla_2_ent.getText();
		            String valor3 = casilla_3_ent.getText();
		            String valor4 = casilla_4_ent.getText();
		            String valor5 = casilla_5_ent.getText();
		            String valor6 = casilla_6_ent.getText();
		            String valor7 = casilla_7_ent.getText();
		            String valor8 = casilla_8_ent.getText();
		            String valor9 = casilla_9_ent.getText();

		            int intValor1 = Integer.parseInt(valor1);
		            int intValor2 = Integer.parseInt(valor2);
		            int intValor3 = Integer.parseInt(valor3);
		            int intValor4 = Integer.parseInt(valor4);
		            int intValor5 = Integer.parseInt(valor5);
		            int intValor6 = Integer.parseInt(valor6);
		            int intValor7 = Integer.parseInt(valor7);
		            int intValor8 = Integer.parseInt(valor8);
		            int intValor9 = Integer.parseInt(valor9);

		            int diagonal_principal_uno = intValor1 * intValor5 * intValor9;
		            int diagonal_principal_dos = intValor4 * intValor8 * intValor3;
		            int diagonal_principal_tres = intValor7 * intValor2 * intValor6;

		            int diagonal_secundaria_uno = intValor3 * intValor5 * intValor7;
		            int diagonal_secundaria_dos = intValor6 * intValor8 * intValor1;
		            int diagonal_secundaria_tres = intValor9 * intValor2 * intValor4;

		            int determinante = (diagonal_principal_uno + diagonal_principal_dos + diagonal_principal_tres) - (diagonal_secundaria_uno + diagonal_secundaria_dos + diagonal_secundaria_tres);

		            if (determinante == 0) {
		                JOptionPane.showMessageDialog(null, "La matriz no tiene inversa porque su determinante es cero.");
		                return;
		            }

		            int[][] transpuesta = new int[3][3];
		            transpuesta[0][0] = intValor1;
		            transpuesta[1][0] = intValor2;
		            transpuesta[2][0] = intValor3;
		            
		            transpuesta[0][1] = intValor4;
		            transpuesta[1][1] = intValor5;
		            transpuesta[2][1] = intValor6;
		            
		            transpuesta[0][2] = intValor7;
		            transpuesta[1][2] = intValor8;
		            transpuesta[2][2] = intValor9;
		            
		            int[][] adjunta = new int[3][3];
		            adjunta[0][0] = (transpuesta[1][1] * transpuesta[2][2]) - (transpuesta[1][2] * transpuesta[2][1]);
		            adjunta[0][1] = -((transpuesta[1][0] * transpuesta[2][2]) - (transpuesta[1][2] * transpuesta[2][0]));
		            adjunta[0][2] = (transpuesta[1][0] * transpuesta[2][1]) - (transpuesta[1][1] * transpuesta[2][0]);

		            adjunta[1][0] = -((transpuesta[0][1] * transpuesta[2][2]) - (transpuesta[0][2] * transpuesta[2][1]));
		            adjunta[1][1] = (transpuesta[0][0] * transpuesta[2][2]) - (transpuesta[0][2] * transpuesta[2][0]);
		            adjunta[1][2] = -((transpuesta[0][0] * transpuesta[2][1]) - (transpuesta[0][1] * transpuesta[2][0]));

		            adjunta[2][0] = (transpuesta[0][1] * transpuesta[1][2]) - (transpuesta[0][2] * transpuesta[1][1]);
		            adjunta[2][1] = -((transpuesta[0][0] * transpuesta[1][2]) - (transpuesta[0][2] * transpuesta[1][0]));
		            adjunta[2][2] = (transpuesta[0][0] * transpuesta[1][1]) - (transpuesta[0][1] * transpuesta[1][0]);

		            String[][] resultado = new String[3][3];

		            resultado[0][0] = simplifyFraction(adjunta[0][0], determinante);
		            resultado[0][1] = simplifyFraction(adjunta[0][1], determinante);
		            resultado[0][2] = simplifyFraction(adjunta[0][2], determinante);

		            resultado[1][0] = simplifyFraction(adjunta[1][0], determinante);
		            resultado[1][1] = simplifyFraction(adjunta[1][1], determinante);
		            resultado[1][2] = simplifyFraction(adjunta[1][2], determinante);

		            resultado[2][0] = simplifyFraction(adjunta[2][0], determinante);
		            resultado[2][1] = simplifyFraction(adjunta[2][1], determinante);
		            resultado[2][2] = simplifyFraction(adjunta[2][2], determinante);
		    		casilla_1_sal.setBounds(34, 11, 70, 70);
		            casilla_1_sal.setText(resultado[0][0]);
		            casilla_2_sal.setVisible(true);
		            casilla_3_sal.setVisible(true);
		            casilla_4_sal.setVisible(true);
		            casilla_5_sal.setVisible(true);
		            casilla_6_sal.setVisible(true);
		            casilla_7_sal.setVisible(true);
		            casilla_8_sal.setVisible(true);
		            casilla_9_sal.setVisible(true);
		            
		            casilla_2_sal.setText(resultado[0][1]);
		            casilla_3_sal.setText(resultado[0][2]);
		            casilla_4_sal.setText(resultado[1][0]);
		            casilla_5_sal.setText(resultado[1][1]);
		            casilla_6_sal.setText(resultado[1][2]);
		            casilla_7_sal.setText(resultado[2][0]);
		            casilla_8_sal.setText(resultado[2][1]);
		            casilla_9_sal.setText(resultado[2][2]);
		        } else {
		            JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");
		        }
		    }

		    private String simplifyFraction(int numerator, int denominator) {
		        if (numerator == 0) {
		            return "0";
		        }
		        int gcd = gcd(Math.abs(numerator), Math.abs(denominator));
		        numerator /= gcd;
		        denominator /= gcd;
		        if (denominator < 0) {
		            numerator = -numerator;
		            denominator = -denominator;
		        }
		        return numerator + "/" + denominator;
		    }

		    private int gcd(int a, int b) {
		        while (b != 0) {
		            int t = b;
		            b = a % b;
		            a = t;
		        }
		        return a;
		    }
		    
		    private boolean areAllFieldsFilled() {
		        return !casilla_1_ent.getText().isEmpty() && 
		               !casilla_2_ent.getText().isEmpty() && 
		               !casilla_3_ent.getText().isEmpty() && 
		               !casilla_4_ent.getText().isEmpty() && 
		               !casilla_5_ent.getText().isEmpty() && 
		               !casilla_6_ent.getText().isEmpty() && 
		               !casilla_7_ent.getText().isEmpty() && 
		               !casilla_8_ent.getText().isEmpty() && 
		               !casilla_9_ent.getText().isEmpty();
		    }
		});		
	}
	
	class RoundedPanel extends JPanel
    {
        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private Color backgroundColor;
        private int cornerRadius = 15;
        public RoundedPanel(LayoutManager layout, int radius) {
            super(layout);
            cornerRadius = radius;
        }
        public RoundedPanel(LayoutManager layout, int radius, Color bgColor) {
            super(layout);
            cornerRadius = radius;
            backgroundColor = bgColor;
        }
        public RoundedPanel(int radius) {
            super();
            cornerRadius = radius;
            
        }
        public RoundedPanel(int radius, Color bgColor) {
            super();
            cornerRadius = radius;
            backgroundColor = bgColor;
        }
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Dimension arcs = new Dimension(cornerRadius, cornerRadius);
            int width = getWidth();
            int height = getHeight();
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            //Draws the rounded panel with borders.
            if (backgroundColor != null) {
                graphics.setColor(backgroundColor);
            } else {
                graphics.setColor(getBackground());
            }
            graphics.fillRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height); //paint background
            graphics.setColor(getForeground());
//            graphics.drawRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height); //paint border
//             
        }
    }
}