import GUI.Ventana_Menu;
import GUI.*;

public class Menu
{
	public static void main(String[] args)
	{
		menuVentana();
	}
	private static void menuVentana()
	{
		VentanaMatricesUno VentanaMatricesUno =new VentanaMatricesUno();//Creo la ventana
		VentanaMatricesUno.setVisible(true);//Ventana visible
	}
}

