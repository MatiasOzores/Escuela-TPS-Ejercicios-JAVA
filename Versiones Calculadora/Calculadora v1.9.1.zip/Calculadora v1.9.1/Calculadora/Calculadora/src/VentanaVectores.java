

import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyAdapter;

public class VentanaVectores extends JInternalFrame{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
    private JDesktopPane desktopPane;
	// Declaracion de variables
	private JTextField casilla_1_ent;
	private JTextField casilla_2_ent;
	private JTextField casilla_3_ent;
	private JTextField casilla_4_ent;
	private JTextField casilla_5_ent;
	private JTextField casilla_6_ent;
	private JTextField casilla_7_ent;
	private JTextField casilla_8_ent;
	private JTextField casilla_9_ent;
	private JTextField casilla_10_ent;

	private JTextField casilla_1_sal;
	private JTextField casilla_2_sal;
	private JTextField casilla_3_sal;
	private JTextField casilla_4_sal;
	private JTextField casilla_5_sal;
	private JTextField casilla_6_sal;
	private JTextField casilla_7_sal;
	private JTextField casilla_8_sal;
	private JTextField casilla_9_sal;
	private JTextField casilla_10_sal;

	private JTextField num_escalar;
	private int spinnerValor = 3;
	


	// Se crea el frame
	public VentanaVectores(JDesktopPane desktopPane) {
        
        super("", false, false, false, false);
        this.desktopPane = desktopPane;
        this.setBorder(null);
        this.setResizable(false);
        this.setClosable(false);
        this.setMaximizable(false);
        this.setIconifiable(false);
        this.setFrameIcon(null);
        this.setLocation(0, 0);
        this.setSize(900, 650);
        this.setVisible(true);

        // Eliminar la barra de título
        ((BasicInternalFrameUI) this.getUI()).setNorthPane(null);

        // Evitar que la ventana se mueva
        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentMoved(ComponentEvent e) {
                setLocation(0, 0);
            }
        });
		
        setBounds(0, 0, 900, 650);
        setResizable(false);
        Color miColorPrin = new Color(26, 27, 40);
        Color miColorSec = new Color(87, 116, 250);
        Color letrasColor = new Color(255, 255, 255);
        Color gris = new Color(30, 36, 53);
        setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        setBounds(0, 0, 900, 650);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(miColorPrin);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
		
		JPanel principal = new JPanel();
		principal.setBackground(miColorPrin);
		principal.setBounds(23, 125, 834, 486);
		contentPane.add(principal);
		principal.setLayout(null);
		
		JPanel mult_escalar = new RoundedPanel(15,miColorSec);
		mult_escalar.setBounds(10, 330, 260, 47);
		principal.add(mult_escalar);
		mult_escalar.setOpaque(false);
		mult_escalar.setLayout(new GridLayout(0, 1, 0, 0));
		
		
		JLabel calc_escalar = new JLabel("Multiplicar por escalar");
		mult_escalar.add(calc_escalar);
		calc_escalar.setForeground(letrasColor);
		calc_escalar.setFont(new Font("Microsoft YaHei", Font.BOLD, 15));
		calc_escalar.setAlignmentX(Component.CENTER_ALIGNMENT);
		calc_escalar.setHorizontalAlignment(SwingConstants.CENTER);
		calc_escalar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		JPanel determinante = new RoundedPanel(15,miColorSec);
		determinante.setBackground(new Color(255, 255, 255));
		determinante.setBounds(280, 330, 274, 47);
		determinante.setOpaque(false);
		principal.add(determinante);
		determinante.setLayout(new GridLayout(1, 0, 0, 0));
		
		JLabel calc_determinante = new JLabel("Suma de vectores");
		determinante.add(calc_determinante);
		calc_determinante.setFont(new Font("Microsoft YaHei", Font.BOLD, 15));
		calc_determinante.setForeground(letrasColor);
		calc_determinante.setHorizontalAlignment(SwingConstants.CENTER);
		calc_determinante.setAlignmentX(0.5f);
		calc_determinante.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		JPanel inversa = new RoundedPanel(15,miColorSec);
		inversa.setBackground(miColorSec);
		inversa.setBounds(564, 330, 260, 47);
		inversa.setOpaque(false);
		principal.add(inversa);
		inversa.setLayout(new GridLayout(1, 0, 0, 0));
		
		JLabel calc_inversa = new JLabel("Resta de vectores");
		inversa.add(calc_inversa);
		calc_inversa.setForeground(letrasColor);
		calc_inversa.setFont(new Font("Microsoft YaHei", Font.BOLD, 15));
		calc_inversa.setHorizontalAlignment(SwingConstants.CENTER);
		calc_inversa.setAlignmentX(0.5f);
		calc_inversa.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		JPanel matrices = new JPanel();
		matrices.setBackground(new Color(0, 64, 128));
		matrices.setBounds(10, 45, 814, 264);
		matrices.setOpaque(false);
		principal.add(matrices);
		matrices.setLayout(null);
		
		JPanel entrada = new JPanel();
		entrada.setBackground(new Color(128, 128, 192));
		entrada.setOpaque(false);
		entrada.setBounds(0, 0, 374, 264);
		matrices.add(entrada);
		entrada.setLayout(null);
		
		casilla_1_ent = new RoundedTextfield(10,gris,Color.WHITE);
		casilla_1_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_1_ent.getText();

		        if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		casilla_1_ent.setBackground(new Color(30, 36, 53));
		casilla_1_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_1_ent.setForeground(new Color(254, 254, 254));
		casilla_1_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_1_ent.setBounds(44, 0, 70, 70);
		entrada.add(casilla_1_ent);
		casilla_1_ent.setColumns(10);
		casilla_1_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_1_ent.setCaretColor(Color.WHITE);
		casilla_1_ent.setVisible(true);
		
		casilla_1_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_1_ent.getText();

		        if (text.length() >= 3 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});		
		
		
		casilla_2_ent = new RoundedTextfield(10,gris,Color.WHITE);
		casilla_2_ent.setBackground(new Color(30, 36, 53));
		casilla_2_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_2_ent.setForeground(new Color(254, 254, 254));
		casilla_2_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_2_ent.setColumns(10);
		casilla_2_ent.setBounds(132, 0, 70, 70);
		casilla_2_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_2_ent.setCaretColor(Color.WHITE);
		casilla_2_ent.setVisible(true);

		casilla_2_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_2_ent.getText();

		        if (text.length() >= 3 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_2_ent);
		
		casilla_3_ent = new RoundedTextfield(10,gris,Color.WHITE);
		casilla_3_ent.setBackground(new Color(30, 36, 53));
		casilla_3_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_3_ent.setForeground(new Color(254, 254, 254));
		casilla_3_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_3_ent.setColumns(10);
		casilla_3_ent.setBounds(220, 0, 70, 70);
		casilla_3_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_3_ent.setCaretColor(Color.WHITE);
		casilla_3_ent.setVisible(true);

		casilla_3_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_3_ent.getText();

		        if (text.length() >= 3 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_3_ent);
		
		casilla_4_ent = new RoundedTextfield(10,gris,Color.WHITE);
		casilla_4_ent.setBackground(new Color(30, 36, 53));
		casilla_4_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_4_ent.setForeground(new Color(254, 254, 254));
		casilla_4_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_4_ent.setColumns(10);
		casilla_4_ent.setBounds(44, 155, 70, 70);
		casilla_4_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_4_ent.setCaretColor(Color.WHITE);
		casilla_4_ent.setVisible(true);

		casilla_4_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_4_ent.getText();

		        if (text.length() >= 3 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_4_ent);
		
		casilla_5_ent = new RoundedTextfield(10,gris,Color.WHITE);
		casilla_5_ent.setBackground(new Color(30, 36, 53));
		casilla_5_ent.setForeground(new Color(254, 254, 254));
		casilla_5_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_5_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_5_ent.setColumns(10);
		casilla_5_ent.setBounds(132, 155, 70, 70);
		casilla_5_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_5_ent.setCaretColor(Color.WHITE);
		casilla_5_ent.setVisible(true);

		casilla_5_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_5_ent.getText();

		        if (text.length() >= 3 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_5_ent);
		
		casilla_6_ent = new RoundedTextfield(10,gris,Color.WHITE);
		casilla_6_ent.setBackground(new Color(30, 36, 53));
		casilla_6_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_6_ent.setForeground(new Color(254, 254, 254));
		casilla_6_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_6_ent.setColumns(10);
		casilla_6_ent.setBounds(220, 155, 70, 70);
		casilla_6_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_6_ent.setCaretColor(Color.WHITE);
		casilla_6_ent.setVisible(true);
		casilla_6_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_6_ent.getText();

		        if (text.length() >= 3 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_6_ent);
		
		casilla_7_ent = new RoundedTextfield(10,gris,Color.WHITE);
		casilla_7_ent.setBackground(new Color(30, 36, 53));
		casilla_7_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_7_ent.setForeground(new Color(254, 254, 254));
		casilla_7_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_7_ent.setColumns(10);
		casilla_7_ent.setBounds(44, 186, 70, 70);
		casilla_7_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_7_ent.setCaretColor(Color.WHITE);
		casilla_7_ent.setVisible(false);
		casilla_7_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_7_ent.getText();

		        if (text.length() >= 3 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_7_ent);
		
		casilla_8_ent = new RoundedTextfield(10,gris,Color.WHITE);
		casilla_8_ent.setBackground(new Color(30, 36, 53));
		casilla_8_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_8_ent.setForeground(new Color(254, 254, 254));
		casilla_8_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_8_ent.setColumns(10);
		casilla_8_ent.setBounds(132, 186, 70, 70);
		casilla_8_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_8_ent.setCaretColor(Color.WHITE);
		casilla_8_ent.setVisible(false);
		casilla_8_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_8_ent.getText();

		        if (text.length() >= 3 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_8_ent);
		
		casilla_9_ent = new RoundedTextfield(10,gris,Color.WHITE);
		casilla_9_ent.setBackground(new Color(30, 36, 53));
		casilla_9_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_9_ent.setForeground(new Color(254, 254, 254));
		casilla_9_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_9_ent.setColumns(10);
		casilla_9_ent.setBounds(220, 186, 70, 70);
		casilla_9_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_9_ent.setCaretColor(Color.WHITE);
		casilla_9_ent.setVisible(false);
		casilla_9_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_9_ent.getText();

		        if (text.length() >= 3 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_9_ent);
		
		// 4x4 
		casilla_10_ent = new RoundedTextfield(10,gris,Color.WHITE);
		casilla_10_ent.setBackground(new Color(30, 36, 53));
		casilla_10_ent.setFont(new Font("Tahoma", Font.BOLD, 18));
		casilla_10_ent.setForeground(new Color(254, 254, 254));
		casilla_10_ent.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_10_ent.setColumns(10);
		casilla_10_ent.setBounds(232, 186, 70, 70);
		casilla_10_ent.setBorder(BorderFactory.createEmptyBorder());
		casilla_10_ent.setCaretColor(Color.WHITE);
		casilla_10_ent.setVisible(false);
		casilla_10_ent.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = casilla_10_ent.getText();

		        if (text.length() >= 3 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});
		entrada.add(casilla_10_ent);
		
		JLabel lblVector_1 = new JLabel("Vector B");
		lblVector_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblVector_1.setForeground(Color.WHITE);
		lblVector_1.setFont(new Font("Microsoft YaHei", Font.BOLD, 16));
		lblVector_1.setBounds(118, 120, 100, 20);
		entrada.add(lblVector_1);
		
		JPanel salida = new JPanel();
		salida.setBorder(null);
		salida.setBackground(new Color(128, 128, 192));
		salida.setBounds(444, 0, 370, 264);
		salida.setOpaque(false);
		matrices.add(salida);
		salida.setLayout(null);
		
		JLabel corchete_izq_1 = new JLabel("");
		corchete_izq_1.setVerticalAlignment(SwingConstants.TOP);
		corchete_izq_1.setHorizontalAlignment(SwingConstants.LEFT);

		corchete_izq_1.setBounds(36, 0, 29, 264);
		salida.add(corchete_izq_1);
		
		JLabel corchete_der_1 = new JLabel("");
		corchete_der_1.setVerticalAlignment(SwingConstants.TOP);
		corchete_der_1.setHorizontalAlignment(SwingConstants.RIGHT);

		corchete_der_1.setBounds(341, 0, 29, 264);
		salida.add(corchete_der_1);
		
		casilla_1_sal = new RoundedTextfield(10,Color.WHITE,gris);
		casilla_1_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_1_sal.setForeground(new Color(30, 36, 53));
		casilla_1_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_1_sal.setColumns(10);
		casilla_1_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_1_sal.setBounds(80, 0, 70, 70);
		casilla_1_sal.setEditable(false); 
		casilla_1_sal.setFocusable(false);
		casilla_1_sal.setVisible(true);
		salida.add(casilla_1_sal);
		
		casilla_2_sal = new RoundedTextfield(10,Color.WHITE,gris);
		casilla_2_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_2_sal.setForeground(new Color(30, 36, 53));
		casilla_2_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_2_sal.setColumns(10);
		casilla_2_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_2_sal.setBounds(168, 0, 70, 70);
		casilla_2_sal.setEditable(false); 
		casilla_2_sal.setFocusable(false);
		casilla_2_sal.setVisible(true);
		salida.add(casilla_2_sal);
		
		casilla_3_sal = new RoundedTextfield(10,Color.WHITE,gris);
		casilla_3_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_3_sal.setForeground(new Color(30, 36, 53));
		casilla_3_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_3_sal.setColumns(10);
		casilla_3_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_3_sal.setBounds(256, 0, 70, 70);
		casilla_3_sal.setEditable(false); 
		casilla_3_sal.setFocusable(false);
		casilla_3_sal.setVisible(true);
		salida.add(casilla_3_sal);
		
		casilla_4_sal = new RoundedTextfield(10,Color.WHITE,gris);
		casilla_4_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_4_sal.setForeground(new Color(30, 36, 53));
		casilla_4_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_4_sal.setColumns(10);
		casilla_4_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_4_sal.setBounds(80, 155, 70, 70);
		casilla_4_sal.setEditable(false); 
		casilla_4_sal.setFocusable(false);
		casilla_4_sal.setVisible(true);
		salida.add(casilla_4_sal);
		
		casilla_5_sal = new RoundedTextfield(10,Color.WHITE,gris);
		casilla_5_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_5_sal.setForeground(new Color(30, 36, 53));
		casilla_5_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_5_sal.setColumns(10);
		casilla_5_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_5_sal.setBounds(168, 155, 70, 70);
		casilla_5_sal.setEditable(false); 
		casilla_5_sal.setFocusable(false);
		casilla_5_sal.setVisible(true);
		salida.add(casilla_5_sal);
		
		casilla_6_sal = new RoundedTextfield(10,Color.WHITE,gris);
		casilla_6_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_6_sal.setForeground(new Color(30, 36, 53));
		casilla_6_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_6_sal.setColumns(10);
		casilla_6_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_6_sal.setBounds(256, 155, 70, 70);
		casilla_6_sal.setEditable(false); 
		casilla_6_sal.setFocusable(false);
		casilla_6_sal.setVisible(true);
		salida.add(casilla_6_sal);
		
		casilla_7_sal = new RoundedTextfield(10,Color.WHITE,gris);
		casilla_7_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_7_sal.setForeground(new Color(30, 36, 53));
		casilla_7_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_7_sal.setColumns(10);
		casilla_7_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_7_sal.setBounds(80, 186, 70, 70);
		casilla_7_sal.setEditable(false); 
		casilla_7_sal.setFocusable(false);
		casilla_7_sal.setVisible(false);
		salida.add(casilla_7_sal);
		
		casilla_8_sal = new RoundedTextfield(10,Color.WHITE,gris);
		casilla_8_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_8_sal.setForeground(new Color(30, 36, 53));
		casilla_8_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_8_sal.setColumns(10);
		casilla_8_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_8_sal.setBounds(168, 186, 70, 70);
		casilla_8_sal.setEditable(false); 
		casilla_8_sal.setFocusable(false);
		casilla_8_sal.setVisible(false);
		salida.add(casilla_8_sal);
		
		casilla_9_sal = new RoundedTextfield(10,Color.WHITE,gris);
		casilla_9_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_9_sal.setForeground(new Color(30, 36, 53));
		casilla_9_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_9_sal.setColumns(10);
		casilla_9_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_9_sal.setBounds(256, 186, 70, 70);
		casilla_9_sal.setEditable(false); 
		casilla_9_sal.setFocusable(false);
		casilla_9_sal.setVisible(false);
		salida.add(casilla_9_sal);
		
		casilla_10_sal = new RoundedTextfield(10,Color.WHITE,gris);
		casilla_10_sal.setHorizontalAlignment(SwingConstants.CENTER);
		casilla_10_sal.setForeground(new Color(100, 36, 53));
		casilla_10_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
		casilla_10_sal.setColumns(10);
		casilla_10_sal.setBorder(BorderFactory.createEmptyBorder());
		casilla_10_sal.setBounds(256, 11, 70, 70);
		casilla_10_sal.setEditable(false); 
		casilla_10_sal.setFocusable(false);
		casilla_10_sal.setVisible(false);
		salida.add(casilla_10_sal);

		
		JLabel igual = new JLabel("=");
		igual.setForeground(new Color(255, 255, 255));
		igual.setFont(new Font("Tahoma", Font.PLAIN, 20));
		igual.setHorizontalAlignment(SwingConstants.CENTER);
		igual.setBounds(368, 99, 80, 29);
		matrices.add(igual);
		
		num_escalar = new RoundedTextfield(10,gris,Color.WHITE);
		num_escalar.setHorizontalAlignment(SwingConstants.CENTER);
		num_escalar.setForeground(new Color(254, 254, 254));
		num_escalar.setFont(new Font("Tahoma", Font.BOLD, 18));
		num_escalar.setColumns(10);
		num_escalar.setBorder(BorderFactory.createEmptyBorder());
		num_escalar.setBackground(new Color(30, 36, 53));
		num_escalar.setBounds(384, 175, 50, 50);
		num_escalar.setCaretColor(Color.WHITE);
		
		num_escalar.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        char c = evt.getKeyChar();
		        String text = num_escalar.getText();

		        int digitCount = text.replace("-", "").length();

		        if (digitCount >= 2 && Character.isDigit(c)) {
		            evt.consume();
		        } else if (!Character.isDigit(c) && (c != '-' || text.contains("-") || text.length() != 0)) {
		            evt.consume();
		        }
		    }
		});	

		matrices.add(num_escalar);
		
		JLabel lblNewLabel = new JLabel("Escalar");
		lblNewLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(388, 155, 46, 14);
		matrices.add(lblNewLabel);

		JSpinner spinner = new JSpinner(new SpinnerNumberModel(3, 3, 5, 1));
		spinner.setFont(new Font("Microsoft YaHei", Font.PLAIN, 13));
		spinner.setBounds(378, 0, 62, 45);
		spinner.setBorder(BorderFactory.createLineBorder(gris));
		spinner.setFocusable(false);
		spinner.setBackground(gris);
		JComponent editor = spinner.getEditor();
		if (editor instanceof JSpinner.DefaultEditor) {
		    JTextField textField = ((JSpinner.DefaultEditor) editor).getTextField();
		    textField.setEditable(false);
		    textField.setFocusable(false); 
		    textField.setBackground(gris);
		    textField.setForeground(letrasColor);
		    textField.setHorizontalAlignment(JTextField.CENTER);
		}

		matrices.add(spinner);

		
		spinner.addChangeListener(new ChangeListener() {
		    @Override
		    public void stateChanged(ChangeEvent e) {
		        SpinnerNumberModel model = (SpinnerNumberModel) spinner.getModel();
		        int valorSpinner = model.getNumber().intValue();

		        JTextField[] casillasEntrada = {casilla_1_ent, casilla_2_ent, casilla_3_ent, casilla_4_ent, casilla_5_ent, casilla_6_ent, casilla_7_ent, casilla_8_ent, casilla_9_ent, casilla_10_ent};
		        JTextField[] casillasSalida = {casilla_1_sal, casilla_2_sal, casilla_3_sal, casilla_4_sal, casilla_5_sal, casilla_6_sal, casilla_7_sal, casilla_8_sal, casilla_9_sal, casilla_10_sal};

		        for (JTextField casilla : casillasEntrada) {
		            casilla.setText("");
		        }

		        for (JTextField casilla : casillasSalida) {
		            casilla.setText("");
		        }

		        // Verificar si el valor del spinner es 4
		        if (valorSpinner == 4) {
		            spinnerValor = 4;
		            casilla_1_ent.setVisible(true);
		            casilla_2_ent.setVisible(true);
		            casilla_3_ent.setVisible(true);
		            casilla_4_ent.setVisible(true);
		            casilla_5_ent.setVisible(true);
		            casilla_6_ent.setVisible(true);
		            casilla_7_ent.setVisible(true);
		            casilla_8_ent.setVisible(true);
		            casilla_9_ent.setVisible(false);
		            casilla_10_ent.setVisible(false);

		            casilla_1_sal.setVisible(true);
		            casilla_2_sal.setVisible(true);
		            casilla_3_sal.setVisible(true);
		            casilla_4_sal.setVisible(true);
		            casilla_5_sal.setVisible(true);
		            casilla_6_sal.setVisible(true);
		            casilla_7_sal.setVisible(true);
		            casilla_8_sal.setVisible(true);
		            casilla_9_sal.setVisible(false);
		            casilla_10_sal.setVisible(false);	            
		            
		            casilla_1_ent.setBounds(44, 17, 50, 50);
		            casilla_2_ent.setBounds(108, 17, 50, 50);
		            casilla_3_ent.setBounds(174, 17, 50, 50);
		            casilla_4_ent.setBounds(240, 17, 50, 50);
		            casilla_5_ent.setBounds(42, 172, 50, 50);
		            casilla_6_ent.setBounds(108, 172, 50, 50);
		            casilla_7_ent.setBounds(174, 172, 50, 50);
		            casilla_8_ent.setBounds(240, 172, 50, 50);

		            casilla_1_sal.setBounds(75, 17, 50, 50);
		            casilla_2_sal.setBounds(145, 17, 50, 50);
		            casilla_3_sal.setBounds(215, 17, 50, 50);
		            casilla_4_sal.setBounds(285, 17, 50, 50);
		            casilla_5_sal.setBounds(75, 172, 50, 50);
		            casilla_6_sal.setBounds(145, 172, 50, 50);
		            casilla_7_sal.setBounds(215, 172, 50, 50);
		            casilla_8_sal.setBounds(285, 172, 50, 50);

		        } else if (valorSpinner == 3) {
		            spinnerValor = 3;
		         
		            casilla_1_ent.setVisible(true);
		            casilla_2_ent.setVisible(true);
		            casilla_3_ent.setVisible(true);
		            casilla_4_ent.setVisible(true);
		            casilla_5_ent.setVisible(true);
		            casilla_6_ent.setVisible(true);
		            casilla_7_ent.setVisible(false);
		            casilla_8_ent.setVisible(false);
		            casilla_9_ent.setVisible(false);
		            casilla_10_ent.setVisible(false);

		            casilla_1_sal.setVisible(true);
		            casilla_2_sal.setVisible(true);
		            casilla_3_sal.setVisible(true);
		            casilla_4_sal.setVisible(true);
		            casilla_5_sal.setVisible(true);
		            casilla_6_sal.setVisible(true);
		            casilla_7_sal.setVisible(false);
		            casilla_8_sal.setVisible(false);
		            casilla_9_sal.setVisible(false);
		            casilla_10_sal.setVisible(false);	     
		            
		            casilla_1_ent.setBounds(44, 0, 70, 70);
		            casilla_2_ent.setBounds(132, 0, 70, 70);
		            casilla_3_ent.setBounds(220, 0, 70, 70);
		            casilla_4_ent.setBounds(44, 155, 70, 70);
		            casilla_5_ent.setBounds(132, 155, 70, 70);
		            casilla_6_ent.setBounds(220, 155, 70, 70);
		            
		            casilla_1_sal.setBounds(80, 0, 70, 70);
		            casilla_2_sal.setBounds(168, 0, 70, 70);
		            casilla_3_sal.setBounds(256, 0, 70, 70);
		            casilla_4_sal.setBounds(80, 155, 70, 70);
		            casilla_5_sal.setBounds(168, 155, 70, 70);
		            casilla_6_sal.setBounds(256, 155, 70, 70);
		        }
		        
		        else {
		            spinnerValor = 5;
		            casilla_1_ent.setVisible(true);
		            casilla_2_ent.setVisible(true);
		            casilla_3_ent.setVisible(true);
		            casilla_4_ent.setVisible(true);
		            casilla_5_ent.setVisible(true);
		            casilla_6_ent.setVisible(true);
		            casilla_7_ent.setVisible(true);
		            casilla_8_ent.setVisible(true);
		            casilla_9_ent.setVisible(true);
		            casilla_10_ent.setVisible(true);

		            casilla_1_sal.setVisible(true);
		            casilla_2_sal.setVisible(true);
		            casilla_3_sal.setVisible(true);
		            casilla_4_sal.setVisible(true);
		            casilla_5_sal.setVisible(true);
		            casilla_6_sal.setVisible(true);
		            casilla_7_sal.setVisible(true);
		            casilla_8_sal.setVisible(true);
		            casilla_9_sal.setVisible(true);
		            casilla_10_sal.setVisible(true);	     
		            
		            
		            casilla_1_ent.setBounds(44, 19, 40, 40);
		            casilla_2_ent.setBounds(95, 19, 40, 40);
		            casilla_3_ent.setBounds(148, 19, 40, 40);
		            casilla_4_ent.setBounds(201, 19, 40, 40);
		            casilla_5_ent.setBounds(254, 19, 40, 40);
		            casilla_6_ent.setBounds(42, 176, 40, 40);
		            casilla_7_ent.setBounds(95, 176, 40, 40);
		            casilla_8_ent.setBounds(148, 176, 40, 40);
		            casilla_9_ent.setBounds(201, 176, 40, 40);
		            casilla_10_ent.setBounds(254, 176, 40, 40);
		            
		            casilla_1_sal.setBounds(80, 19, 40, 40);
		            casilla_2_sal.setBounds(133, 19, 40, 40);
		            casilla_3_sal.setBounds(186, 19, 40, 40);
		            casilla_4_sal.setBounds(239, 19, 40, 40);
		            casilla_5_sal.setBounds(292, 19, 40, 40);
		            casilla_6_sal.setBounds(80, 176, 40, 40);
		            casilla_7_sal.setBounds(133, 176, 40, 40);
		            casilla_8_sal.setBounds(186, 176, 40, 40);
		            casilla_9_sal.setBounds(239, 176, 40, 40);
		            casilla_10_sal.setBounds(292, 176, 40, 40);
		            
		        }
		    }
		});
		
		RoundedPanel clear = new RoundedPanel(10, Color.WHITE);
		clear.setBounds(374, 58, 70, 29);
		matrices.add(clear);
		clear.setOpaque(false);
		clear.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		clear.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel clear_uno = new JLabel("BORRAR");
		clear_uno.setHorizontalAlignment(SwingConstants.CENTER);
		clear_uno.setForeground(new Color(86, 116, 250));
		clear_uno.setFont(new Font("Microsoft YaHei", Font.BOLD, 12));
		clear.add(clear_uno);
		
		clear.addMouseListener(new MouseAdapter() {
		    @Override
            public void mousePressed(MouseEvent e) {
                // Acción al presionar el mouse
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            	casilla_1_ent.requestFocus();
            	casilla_1_ent.setText("");
            	casilla_2_ent.setText("");
            	casilla_3_ent.setText("");
            	casilla_4_ent.setText("");
            	casilla_5_ent.setText("");
            	casilla_6_ent.setText("");
            	casilla_7_ent.setText("");
            	casilla_8_ent.setText("");
            	casilla_9_ent.setText("");
            	casilla_10_ent.setText("");
            }			
			
		});
				
		JPanel menu_general = new JPanel();
		menu_general.setBackground(miColorPrin);
		menu_general.setBounds(23, 34, 834, 80);
		contentPane.add(menu_general);
		menu_general.setLayout(null);
		
		JPanel aritmeticas = new RoundedPanel(15, Color.WHITE);
		aritmeticas.setForeground(new Color(86, 116, 253));
		
		aritmeticas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				aritmeticas.setBackground(new Color(155, 172, 254));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				aritmeticas.setBackground(new Color(255, 255, 255));
			}
			
		    @Override
            public void mousePressed(MouseEvent e) {
                // Acción al presionar el mouse
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                // Acción al soltar el mouse
                abrirVentanaEstandar();
            }
		});
		aritmeticas.setBackground(new Color(255, 255, 255));
		aritmeticas.setBounds(10, 11, 185, 58);
		aritmeticas.setOpaque(false);
		menu_general.add(aritmeticas);
		aritmeticas.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel texto_aritmeticas = new JLabel("ESTANDAR");
		texto_aritmeticas.setFont(new Font("Microsoft YaHei", Font.BOLD, 14));
		texto_aritmeticas.setForeground(new Color(30, 36, 53));
		texto_aritmeticas.setHorizontalAlignment(SwingConstants.CENTER);
		texto_aritmeticas.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		aritmeticas.add(texto_aritmeticas);
		
		
		JPanel vectores = new RoundedPanel(15,miColorSec);
		vectores.setBackground(miColorSec);
		vectores.setBounds(221, 11, 185, 58);
		vectores.setOpaque(false);
		menu_general.add(vectores);
		vectores.setLayout(new GridLayout(1, 0, 0, 0));
				
		JLabel texto_vectores = new JLabel("VECTORES");
		texto_vectores.setBackground(miColorSec);
		texto_vectores.setHorizontalAlignment(SwingConstants.CENTER);
		texto_vectores.setForeground(letrasColor);
		texto_vectores.setFont(new Font("Microsoft YaHei", Font.BOLD, 14));
		texto_vectores.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		vectores.add(texto_vectores);
		
		JPanel matrices_operaciones = new RoundedPanel(15,Color.WHITE);
		matrices_operaciones.setBackground(Color.WHITE);
		matrices_operaciones.setBounds(432, 11, 185, 58);
		matrices_operaciones.setOpaque(false);
		menu_general.add(matrices_operaciones);
		matrices_operaciones.setLayout(new GridLayout(1, 0, 0, 0));
		
		matrices_operaciones.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				matrices_operaciones.setBackground(new Color(155, 172, 254));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				matrices_operaciones.setBackground(new Color(255, 255, 255));
			}
			
		    @Override
            public void mousePressed(MouseEvent e) {
                // Acción al presionar el mouse
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                // Acción al soltar el mouse
                abrirVentanaMatricesUno();
            
            }
		});
		
		JLabel texto_matrices = new JLabel("MATRICES");
		texto_matrices.setHorizontalAlignment(SwingConstants.CENTER);
		texto_matrices.setForeground(new Color(30, 36, 53));
		texto_matrices.setFont(new Font("Microsoft YaHei", Font.BOLD, 14));
		texto_matrices.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		matrices_operaciones.add(texto_matrices);
		
		JPanel ecuaciones = new RoundedPanel(15,Color.WHITE);
		ecuaciones.setBackground(Color.WHITE);
		ecuaciones.setBounds(639, 11, 185, 58);
		ecuaciones.setOpaque(false);
		menu_general.add(ecuaciones);
		ecuaciones.setLayout(new GridLayout(1, 0, 0, 0));
		
		ecuaciones.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				ecuaciones.setBackground(new Color(155, 172, 254));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				ecuaciones.setBackground(new Color(255, 255, 255));
			}
			
		    @Override
            public void mousePressed(MouseEvent e) {
                // Acción al presionar el mouse
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                // Acción al soltar el mouse
                abrirVentanaEcuaciones();
            }
		});
		
		JLabel texto_ecuaciones = new JLabel("ECUACIONES");
		texto_ecuaciones.setHorizontalAlignment(SwingConstants.CENTER);
		texto_ecuaciones.setForeground(new Color(30, 36, 53));
		texto_ecuaciones.setFont(new Font("Microsoft YaHei", Font.BOLD, 14));
		texto_ecuaciones.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		ecuaciones.add(texto_ecuaciones);
				
		JPanel mult_escalar_1 = new RoundedPanel(15, new Color(87, 116, 250));
		mult_escalar_1.setOpaque(false);
		mult_escalar_1.setBounds(153, 390, 260, 47);
		principal.add(mult_escalar_1);
		mult_escalar_1.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel calc_escalar_1 = new JLabel("Producto escalar");
		mult_escalar_1.add(calc_escalar_1);
		calc_escalar_1.setHorizontalAlignment(SwingConstants.CENTER);
		calc_escalar_1.setForeground(Color.WHITE);
		calc_escalar_1.setFont(new Font("Microsoft YaHei", Font.BOLD, 15));
		calc_escalar_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		calc_escalar_1.setAlignmentX(0.5f);
		
		RoundedPanel mult_escalar_2 = new RoundedPanel(15, new Color(87, 116, 250));
		mult_escalar_2.setOpaque(false);
		mult_escalar_2.setBounds(426, 390, 260, 47);
		principal.add(mult_escalar_2);
		mult_escalar_2.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel calc_escalar_2 = new JLabel("Producto vectorial");
		mult_escalar_2.add(calc_escalar_2);
		calc_escalar_2.setHorizontalAlignment(SwingConstants.CENTER);
		calc_escalar_2.setForeground(Color.WHITE);
		calc_escalar_2.setFont(new Font("Microsoft YaHei", Font.BOLD, 15));
		calc_escalar_2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		calc_escalar_2.setAlignmentX(0.5f);
		
		JLabel lblVector = new JLabel("Vector A");
		lblVector.setBounds(127, 11, 100, 20);
		principal.add(lblVector);
		lblVector.setHorizontalAlignment(SwingConstants.CENTER);
		lblVector.setForeground(Color.WHITE);
		lblVector.setFont(new Font("Microsoft YaHei", Font.BOLD, 16));
		
				
				
				JLabel lblLongitud = new JLabel("Longitud");
				lblLongitud.setBounds(329, 18, 178, 20);
				principal.add(lblLongitud);
				lblLongitud.setHorizontalAlignment(SwingConstants.CENTER);
				lblLongitud.setForeground(Color.WHITE);
				lblLongitud.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
		
		// Parte logica simplificada
				mult_escalar.addMouseListener(new java.awt.event.MouseAdapter() {
		            @Override
		            public void mousePressed(MouseEvent e) {
		                // Acción al presionar el mouse
		            }
					
				    @Override
				    public void mouseReleased(java.awt.event.MouseEvent evt) {
				        	if(spinnerValor == 4) {
				        		if(areAllFieldsFilled4X4()) {
				        			
						    		casilla_1_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_2_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_3_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_4_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_5_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_6_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_7_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_8_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						            casilla_1_sal.setBounds(75, 17, 50, 50);
						            casilla_2_sal.setBounds(145, 17, 50, 50);
						            casilla_3_sal.setBounds(215, 17, 50, 50);
						            casilla_4_sal.setBounds(285, 17, 50, 50);
						            casilla_5_sal.setBounds(75, 172, 50, 50);
						            casilla_6_sal.setBounds(145, 172, 50, 50);
						            casilla_7_sal.setBounds(215, 172, 50, 50);
						            casilla_8_sal.setBounds(285, 172, 50, 50);
						    		
						    		
					        		String valor1 = casilla_1_ent.getText();
						        	String valor2 = casilla_2_ent.getText();
						        	String valor3 = casilla_3_ent.getText();
						        	String valor4 = casilla_4_ent.getText();
						        	String valor5 = casilla_5_ent.getText();
						        	String valor6 = casilla_6_ent.getText();
						        	String valor7 = casilla_7_ent.getText();
						        	String valor8 = casilla_8_ent.getText();
						     
						        	String escalar_num = num_escalar.getText();
						        	
						        	int[] vector1 = new int[4];
						        	int[] vector2 = new int[4];
						        	vector1[0] = Integer.parseInt(valor1);
						        	vector1[1] = Integer.parseInt(valor2);
						        	vector1[2] = Integer.parseInt(valor3);
						        	vector1[3] = Integer.parseInt(valor4);
						        	
						        	vector2[0] = Integer.parseInt(valor5);
						        	vector2[1] = Integer.parseInt(valor6);
						        	vector2[2] = Integer.parseInt(valor7);
						        	vector2[3] = Integer.parseInt(valor8);
						        							        	
						        	int numEscalar = Integer.parseInt(escalar_num);
						        	
						        	multEscalar(vector1, vector2, numEscalar, spinnerValor);
		
						    		casilla_1_sal.setBounds(75, 17, 50, 50);
						    		casilla_1_sal.setVisible(true);
						            casilla_2_sal.setVisible(true);
						            casilla_3_sal.setVisible(true);
						            casilla_4_sal.setVisible(true);
						            casilla_5_sal.setVisible(true);
						            casilla_6_sal.setVisible(true);
						            casilla_7_sal.setVisible(true);
						            casilla_8_sal.setVisible(true);
						                      				        			
				        		}
				        		
				        		else {
									JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");						        			
				        		}
				        	}
				        	
				        	else if(spinnerValor == 3) {
				        		if(areAllFieldsFilled3X3()) {
					        		String valor1 = casilla_1_ent.getText();
						        	String valor2 = casilla_2_ent.getText();
						        	String valor3 = casilla_3_ent.getText();
						        	String valor4 = casilla_4_ent.getText();
						        	String valor5 = casilla_5_ent.getText();
						        	String valor6 = casilla_6_ent.getText();

						        	String escalar_num = num_escalar.getText();
						        	
						        	int[] vector1 = new int[3];
						        	int[] vector2 = new int[3];
						        	vector1[0] = Integer.parseInt(valor1);
						        	vector1[1] = Integer.parseInt(valor2);
						        	vector1[2] = Integer.parseInt(valor3);
						        	
						        	vector2[0] = Integer.parseInt(valor4);
						        	vector2[1] = Integer.parseInt(valor5);
						        	vector2[2] = Integer.parseInt(valor6);
						        							        	
						        	int numEscalar = Integer.parseInt(escalar_num);
						        	
						        	multEscalar(vector1, vector2, numEscalar, spinnerValor);
						            casilla_2_sal.setBounds(168, 0, 70, 70);
						            casilla_3_sal.setBounds(256, 0, 70, 70);
						    		casilla_1_sal.setBounds(80, 0, 70, 70);
						    		casilla_1_sal.setVisible(true);
						            casilla_2_sal.setVisible(true);
						            casilla_3_sal.setVisible(true);
						            casilla_4_sal.setVisible(true);
						            casilla_5_sal.setVisible(true);
						            casilla_6_sal.setVisible(true);						            
				        		}
				        		
					        	else {
									JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");						        		
					        	}
				        	}
				        	
				        	else {
				        		if(areAllFieldsFilled5x5()) {
					        		String valor1 = casilla_1_ent.getText();
						        	String valor2 = casilla_2_ent.getText();
						        	String valor3 = casilla_3_ent.getText();
						        	String valor4 = casilla_4_ent.getText();
						        	String valor5 = casilla_5_ent.getText();
						        	String valor6 = casilla_6_ent.getText();
						        	String valor7 = casilla_7_ent.getText();
						        	String valor8 = casilla_8_ent.getText();
						        	String valor9 = casilla_9_ent.getText();
						        	String valor10 = casilla_10_ent.getText();
						        	String escalar_num = num_escalar.getText();
						        	
						        	int[] vector1 = new int[5];
						        	int[] vector2 = new int[5];
						        	vector1[0] = Integer.parseInt(valor1);
						        	vector1[1] = Integer.parseInt(valor2);
						        	vector1[2] = Integer.parseInt(valor3);
						        	vector1[3] = Integer.parseInt(valor4);
						        	vector1[4] = Integer.parseInt(valor5);
						        	
						        	vector2[0] = Integer.parseInt(valor6);
						        	vector2[1] = Integer.parseInt(valor7);
						        	vector2[2] = Integer.parseInt(valor8);
						        	vector2[3] = Integer.parseInt(valor9);
						        	vector2[4] = Integer.parseInt(valor10);
						        							        	
						        	int numEscalar = Integer.parseInt(escalar_num);
						        	
						    		casilla_1_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_2_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_3_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_4_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_5_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_6_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_7_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_8_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_9_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_10_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		
						    		casilla_1_sal.setBounds(80, 19, 40, 40);
						            casilla_2_sal.setBounds(133, 19, 40, 40);
						            casilla_3_sal.setBounds(186, 19, 40, 40);
						            casilla_4_sal.setBounds(239, 19, 40, 40);
						            casilla_5_sal.setBounds(292, 19, 40, 40);
						            casilla_6_sal.setBounds(80, 176, 40, 40);
						            casilla_7_sal.setBounds(133, 176, 40, 40);
						            casilla_8_sal.setBounds(186, 176, 40, 40);
						            casilla_9_sal.setBounds(239, 176, 40, 40);
						            casilla_10_sal.setBounds(292, 176, 40, 40);
						            
						    		casilla_1_sal.setVisible(true);
						            casilla_2_sal.setVisible(true);
						            casilla_3_sal.setVisible(true);
						            casilla_4_sal.setVisible(true);
						            casilla_5_sal.setVisible(true);
						            casilla_6_sal.setVisible(true);
						            casilla_7_sal.setVisible(true);
						            casilla_8_sal.setVisible(true);
						            casilla_9_sal.setVisible(true);
						            casilla_10_sal.setVisible(true);

						        	multEscalar(vector1, vector2, numEscalar, spinnerValor);
				        		}
				        		
					        	else {
									JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");						        		
					        	}
				        	}				        		
				        	
				        	
			
				    }

				    private boolean areAllFieldsFilled3X3() {
				        return !num_escalar.getText().isEmpty() &&
				        	   !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty();
				    }
				    
				    private boolean areAllFieldsFilled4X4() {
				        return !num_escalar.getText().isEmpty() &&
				        	   !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty() && 
				               !casilla_7_ent.getText().isEmpty() && 
				               !casilla_8_ent.getText().isEmpty();
				    }
				    
				    private boolean areAllFieldsFilled5x5() {
				        return !num_escalar.getText().isEmpty() &&
				        	   !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty() && 
				               !casilla_7_ent.getText().isEmpty() && 
				               !casilla_8_ent.getText().isEmpty() && 
				               !casilla_9_ent.getText().isEmpty() && 
				               !casilla_10_ent.getText().isEmpty();
				    }
				});

				determinante.addMouseListener(new java.awt.event.MouseAdapter() {

		            @Override
		            public void mousePressed(MouseEvent e) {
		                // Acción al presionar el mouse
		            }
				    
				    @Override
					public void mouseReleased(MouseEvent e) {

			        	if(spinnerValor == 4) {
								if (areAllFieldsFilled4X4()) {
									
						    		casilla_1_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		
						    		casilla_1_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_2_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_3_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_4_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_5_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_6_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_7_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_8_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    	
						    		
								            						        	
						            casilla_1_sal.setVisible(true);
						            casilla_2_sal.setVisible(true);
						            casilla_3_sal.setVisible(true);
						            casilla_4_sal.setVisible(true);
						            casilla_5_sal.setVisible(false);
						            casilla_6_sal.setVisible(false);
						            casilla_7_sal.setVisible(false);
						            casilla_8_sal.setVisible(false);
						            
						            casilla_9_sal.setVisible(false);
						            casilla_10_sal.setVisible(false);
						           
									
					        		String valor1 = casilla_1_ent.getText();
						        	String valor2 = casilla_2_ent.getText();
						        	String valor3 = casilla_3_ent.getText();
						        	String valor4 = casilla_4_ent.getText();
						        	String valor5 = casilla_5_ent.getText();
						        	String valor6 = casilla_6_ent.getText();
						        	String valor7 = casilla_7_ent.getText();
						        	String valor8 = casilla_8_ent.getText();
						        	
						        	int[] vector1 = new int[4];
						        	int[] vector2 = new int[4];
						        	vector1[0] = Integer.parseInt(valor1);
						        	vector1[1] = Integer.parseInt(valor2);
						        	vector1[2] = Integer.parseInt(valor3);
						        	vector1[3] = Integer.parseInt(valor4);
						        	
						        	vector2[0] = Integer.parseInt(valor5);
						        	vector2[1] = Integer.parseInt(valor6);
						        	vector2[2] = Integer.parseInt(valor7);
						        	vector2[3] = Integer.parseInt(valor8);
						        							        	
						            casilla_1_sal.setBounds(75, 99, 50, 50);
						            casilla_2_sal.setBounds(145, 99, 50, 50);
						            casilla_3_sal.setBounds(215, 99, 50, 50);
						            casilla_4_sal.setBounds(285, 99, 50, 50);
						            
						        	vectorSuma(vector1, vector2, spinnerValor);	
		

						            
				        	}
								
							else {
								JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");							
							}
			        	}
			        	
		        		else if(spinnerValor == 3) {
		        				if(areAllFieldsFilled3X3()) {
						        		String valor1 = casilla_1_ent.getText();
							        	String valor2 = casilla_2_ent.getText();
							        	String valor3 = casilla_3_ent.getText();
							        	String valor4 = casilla_4_ent.getText();
							        	String valor5 = casilla_5_ent.getText();
							        	String valor6 = casilla_6_ent.getText();
		
							        	int[] vector1 = new int[3];
							        	int[] vector2 = new int[3];
							        	vector1[0] = Integer.parseInt(valor1);
							        	vector1[1] = Integer.parseInt(valor2);
							        	vector1[2] = Integer.parseInt(valor3);
							        	
							        	vector2[0] = Integer.parseInt(valor4);
							        	vector2[1] = Integer.parseInt(valor5);
							        	vector2[2] = Integer.parseInt(valor6);
							        			
							        	casilla_1_sal.setBounds(80, 83, 70, 70);
							            casilla_2_sal.setBounds(168, 83, 70, 70);
							            casilla_3_sal.setBounds(256, 83, 70, 70);
							            
							            casilla_1_sal.setVisible(true);
							            casilla_2_sal.setVisible(true);
							            casilla_3_sal.setVisible(true);
							            
							            casilla_4_sal.setVisible(false);
							            casilla_5_sal.setVisible(false);
							            casilla_6_sal.setVisible(false);
							            casilla_7_sal.setVisible(false);
							            casilla_8_sal.setVisible(false);
							            casilla_9_sal.setVisible(false);
							            casilla_10_sal.setVisible(false);
								            							        	
							        	vectorSuma(vector1, vector2, spinnerValor);	

		        				}
				        		
		        				else {
									JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");			        					
		        				}
				        
						}
					
		        		else {
							if (areAllFieldsFilled5x5()) {	
					    		casilla_1_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_2_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_3_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_4_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_5_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_6_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_7_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_8_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_9_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_10_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));

					    		casilla_1_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_2_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_3_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_4_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_5_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_6_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_7_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_8_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_9_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_10_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));

				        		String valor1 = casilla_1_ent.getText();
					        	String valor2 = casilla_2_ent.getText();
					        	String valor3 = casilla_3_ent.getText();
					        	String valor4 = casilla_4_ent.getText();
					        	String valor5 = casilla_5_ent.getText();
					        	String valor6 = casilla_6_ent.getText();
					        	String valor7 = casilla_7_ent.getText();
					        	String valor8 = casilla_8_ent.getText();
					        	String valor9 = casilla_9_ent.getText();
					        	String valor10 = casilla_10_ent.getText();
					        
			        	
					        	int[] vector1 = new int[5];
					        	int[] vector2 = new int[5];
					        	vector1[0] = Integer.parseInt(valor1);
					        	vector1[1] = Integer.parseInt(valor2);
					        	vector1[2] = Integer.parseInt(valor3);
					        	vector1[3] = Integer.parseInt(valor4);
					        	vector1[4] = Integer.parseInt(valor5);
					        	
					        	vector2[0] = Integer.parseInt(valor6);
					        	vector2[1] = Integer.parseInt(valor7);
					        	vector2[2] = Integer.parseInt(valor8);
					        	vector2[3] = Integer.parseInt(valor9);
					        	vector2[4] = Integer.parseInt(valor10);

					            casilla_1_sal.setVisible(true);
					            casilla_2_sal.setVisible(true);
					            casilla_3_sal.setVisible(true);
					            casilla_4_sal.setVisible(true);
					            casilla_5_sal.setVisible(true);
					            casilla_1_sal.setBounds(80, 99, 40, 40);
					            casilla_2_sal.setBounds(133, 99, 40, 40);
					            casilla_3_sal.setBounds(186, 99, 40, 40);
					            casilla_4_sal.setBounds(239, 99, 40, 40);
					            casilla_5_sal.setBounds(292, 99, 40, 40);

					            
					            casilla_6_sal.setVisible(false);
					            casilla_7_sal.setVisible(false);
					            casilla_8_sal.setVisible(false);
					            casilla_9_sal.setVisible(false);
					            casilla_10_sal.setVisible(false);
			            
					        	vectorSuma(vector1, vector2, spinnerValor);
					        	
			        	}
							
						else {
							JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");							
						}		        			
		        		}
			        	
					}
					
				    private boolean areAllFieldsFilled3X3() {
				        return !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty();
				    }
				    
				    private boolean areAllFieldsFilled4X4() {
				        return !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty() && 
				               !casilla_7_ent.getText().isEmpty() && 
				               !casilla_8_ent.getText().isEmpty();
				    }
				    
				    private boolean areAllFieldsFilled5x5() {
				        return !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty() && 
				               !casilla_7_ent.getText().isEmpty() && 
				               !casilla_8_ent.getText().isEmpty() && 
				               !casilla_9_ent.getText().isEmpty() && 
				               !casilla_10_ent.getText().isEmpty();
				    }
				    
				});
				
				inversa.addMouseListener(new java.awt.event.MouseAdapter() {
		            @Override
		            public void mousePressed(MouseEvent e) {
		                // Acción al presionar el mouse
		            }

		            @Override
				    public void mouseReleased(MouseEvent e) {
				        if(spinnerValor == 4) {
					        if (areAllFieldsFilled4X4()) {
					    		casilla_1_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
					    		
					    		casilla_1_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
					    		casilla_2_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
					    		casilla_3_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
					    		casilla_4_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
					    		casilla_5_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
					    		casilla_6_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
					    		casilla_7_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
					    		casilla_8_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
					    	
					    		
							            						        	
					            casilla_1_sal.setVisible(true);
					            casilla_2_sal.setVisible(true);
					            casilla_3_sal.setVisible(true);
					            casilla_4_sal.setVisible(true);
					            casilla_5_sal.setVisible(false);
					            casilla_6_sal.setVisible(false);
					            casilla_7_sal.setVisible(false);
					            casilla_8_sal.setVisible(false);
					            
					            casilla_9_sal.setVisible(false);
					            casilla_10_sal.setVisible(false);
					           
								
				        		String valor1 = casilla_1_ent.getText();
					        	String valor2 = casilla_2_ent.getText();
					        	String valor3 = casilla_3_ent.getText();
					        	String valor4 = casilla_4_ent.getText();
					        	String valor5 = casilla_5_ent.getText();
					        	String valor6 = casilla_6_ent.getText();
					        	String valor7 = casilla_7_ent.getText();
					        	String valor8 = casilla_8_ent.getText();
					        	
					        	int[] vector1 = new int[4];
					        	int[] vector2 = new int[4];
					        	vector1[0] = Integer.parseInt(valor1);
					        	vector1[1] = Integer.parseInt(valor2);
					        	vector1[2] = Integer.parseInt(valor3);
					        	vector1[3] = Integer.parseInt(valor4);
					        	
					        	vector2[0] = Integer.parseInt(valor5);
					        	vector2[1] = Integer.parseInt(valor6);
					        	vector2[2] = Integer.parseInt(valor7);
					        	vector2[3] = Integer.parseInt(valor8);
					        							        	
					            casilla_1_sal.setBounds(75, 99, 50, 50);
					            casilla_2_sal.setBounds(145, 99, 50, 50);
					            casilla_3_sal.setBounds(215, 99, 50, 50);
					            casilla_4_sal.setBounds(285, 99, 50, 50);
					            
					        	vectorResta(vector1, vector2, spinnerValor);		
					        } else {
					            JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");
					        }				        	
				        }
				        
				        else if(spinnerValor == 3) {
					        if (areAllFieldsFilled3X3()) {
				        		String valor1 = casilla_1_ent.getText();
					        	String valor2 = casilla_2_ent.getText();
					        	String valor3 = casilla_3_ent.getText();
					        	String valor4 = casilla_4_ent.getText();
					        	String valor5 = casilla_5_ent.getText();
					        	String valor6 = casilla_6_ent.getText();

					        	int[] vector1 = new int[3];
					        	int[] vector2 = new int[3];
					        	vector1[0] = Integer.parseInt(valor1);
					        	vector1[1] = Integer.parseInt(valor2);
					        	vector1[2] = Integer.parseInt(valor3);
					        	
					        	vector2[0] = Integer.parseInt(valor4);
					        	vector2[1] = Integer.parseInt(valor5);
					        	vector2[2] = Integer.parseInt(valor6);
					        			
					        	casilla_1_sal.setBounds(80, 83, 70, 70);
					            casilla_2_sal.setBounds(168, 83, 70, 70);
					            casilla_3_sal.setBounds(256, 83, 70, 70);
					            
					            casilla_1_sal.setVisible(true);
					            casilla_2_sal.setVisible(true);
					            casilla_3_sal.setVisible(true);
					            
					            casilla_4_sal.setVisible(false);
					            casilla_5_sal.setVisible(false);
					            casilla_6_sal.setVisible(false);
					            casilla_7_sal.setVisible(false);
					            casilla_8_sal.setVisible(false);
					            casilla_9_sal.setVisible(false);
					            casilla_10_sal.setVisible(false);
						            							        	
					        	vectorResta(vector1, vector2, spinnerValor);	
					        } else {
					            JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");
					        }				        	
				        }
				        
				        else {
				            if (areAllFieldsFilled5x5()) {
				            	
					    		casilla_1_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_2_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_3_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_4_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_5_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_6_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_7_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_8_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_9_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_10_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));

					    		casilla_1_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_2_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_3_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_4_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_5_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_6_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_7_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_8_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_9_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
					    		casilla_10_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));

				        		String valor1 = casilla_1_ent.getText();
					        	String valor2 = casilla_2_ent.getText();
					        	String valor3 = casilla_3_ent.getText();
					        	String valor4 = casilla_4_ent.getText();
					        	String valor5 = casilla_5_ent.getText();
					        	String valor6 = casilla_6_ent.getText();
					        	String valor7 = casilla_7_ent.getText();
					        	String valor8 = casilla_8_ent.getText();
					        	String valor9 = casilla_9_ent.getText();
					        	String valor10 = casilla_10_ent.getText();
					        
			        	
					        	int[] vector1 = new int[5];
					        	int[] vector2 = new int[5];
					        	vector1[0] = Integer.parseInt(valor1);
					        	vector1[1] = Integer.parseInt(valor2);
					        	vector1[2] = Integer.parseInt(valor3);
					        	vector1[3] = Integer.parseInt(valor4);
					        	vector1[4] = Integer.parseInt(valor5);
					        	
					        	vector2[0] = Integer.parseInt(valor6);
					        	vector2[1] = Integer.parseInt(valor7);
					        	vector2[2] = Integer.parseInt(valor8);
					        	vector2[3] = Integer.parseInt(valor9);
					        	vector2[4] = Integer.parseInt(valor10);

					            casilla_1_sal.setVisible(true);
					            casilla_2_sal.setVisible(true);
					            casilla_3_sal.setVisible(true);
					            casilla_4_sal.setVisible(true);
					            casilla_5_sal.setVisible(true);
					            casilla_1_sal.setBounds(80, 99, 40, 40);
					            casilla_2_sal.setBounds(133, 99, 40, 40);
					            casilla_3_sal.setBounds(186, 99, 40, 40);
					            casilla_4_sal.setBounds(239, 99, 40, 40);
					            casilla_5_sal.setBounds(292, 99, 40, 40);

					            
					            casilla_6_sal.setVisible(false);
					            casilla_7_sal.setVisible(false);
					            casilla_8_sal.setVisible(false);
					            casilla_9_sal.setVisible(false);
					            casilla_10_sal.setVisible(false);
			            
					        	vectorResta(vector1, vector2, spinnerValor);
				            }
				            
				        	else {
				                JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");
				                return;
				        	}
				        }


				    }
				    
				    private boolean areAllFieldsFilled3X3() {
				        return !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty();
				    }
				    
				    private boolean areAllFieldsFilled4X4() {
				        return !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty() && 
				               !casilla_7_ent.getText().isEmpty() && 
				               !casilla_8_ent.getText().isEmpty();
				    }
				    
				    private boolean areAllFieldsFilled5x5() {
				        return !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty() && 
				               !casilla_7_ent.getText().isEmpty() && 
				               !casilla_8_ent.getText().isEmpty() && 
				               !casilla_9_ent.getText().isEmpty() && 
				               !casilla_10_ent.getText().isEmpty();
				    }
				});
				
				mult_escalar_1.addMouseListener(new java.awt.event.MouseAdapter() {
		            @Override
		            public void mousePressed(MouseEvent e) {
		                // Acción al presionar el mouse
		            }

		            @Override
				    public void mouseReleased(java.awt.event.MouseEvent evt) {
				        	if(spinnerValor == 4) {
				        		if(areAllFieldsFilled4X4()) {
				        			
						    		casilla_1_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_2_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_3_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_4_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_5_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_6_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_7_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_8_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 15));

						    		
						    		casilla_1_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_2_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_3_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_4_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_5_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_6_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_7_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
						    		casilla_8_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 15));
	

				        			
					        		String valor1 = casilla_1_ent.getText();
						        	String valor2 = casilla_2_ent.getText();
						        	String valor3 = casilla_3_ent.getText();
						        	String valor4 = casilla_4_ent.getText();
						        	String valor5 = casilla_5_ent.getText();
						        	String valor6 = casilla_6_ent.getText();
						        	String valor7 = casilla_7_ent.getText();
						        	String valor8 = casilla_8_ent.getText();

						        	String escalar_num = num_escalar.getText();
						        	
						        	int[] vector1 = new int[4];
						        	int[] vector2 = new int[4];
						        	vector1[0] = Integer.parseInt(valor1);
						        	vector1[1] = Integer.parseInt(valor2);
						        	vector1[2] = Integer.parseInt(valor3);
						        	vector1[3] = Integer.parseInt(valor4);
						        	
						        	vector2[0] = Integer.parseInt(valor5);
						        	vector2[1] = Integer.parseInt(valor6);
						        	vector2[2] = Integer.parseInt(valor7);
						        	vector2[3] = Integer.parseInt(valor8);
						        							        	
						        	int numEscalar = Integer.parseInt(escalar_num);
						        	

						    		casilla_1_sal.setVisible(true);
						            casilla_2_sal.setVisible(false);
						            casilla_3_sal.setVisible(false);
						            casilla_4_sal.setVisible(false);
						            casilla_5_sal.setVisible(false);
						            casilla_6_sal.setVisible(false);
						            casilla_7_sal.setVisible(false);
						            casilla_8_sal.setVisible(false);
						            casilla_9_sal.setVisible(false);
						            casilla_10_sal.setVisible(false);

						            
						        	productoEscalar(vector1, vector2, numEscalar, spinnerValor);
						            				        			
				        		}
				        		
				        		else {
									JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");						        			
				        		}
				        	}
				        	
				        	else if(spinnerValor == 3) {
				        		if(areAllFieldsFilled3X3()) {
					        		String valor1 = casilla_1_ent.getText();
						        	String valor2 = casilla_2_ent.getText();
						        	String valor3 = casilla_3_ent.getText();
						        	String valor4 = casilla_4_ent.getText();
						        	String valor5 = casilla_5_ent.getText();
						        	String valor6 = casilla_6_ent.getText();

						        	String escalar_num = num_escalar.getText();
						        	
						        	int[] vector1 = new int[3];
						        	int[] vector2 = new int[3];
						        	vector1[0] = Integer.parseInt(valor1);
						        	vector1[1] = Integer.parseInt(valor2);
						        	vector1[2] = Integer.parseInt(valor3);
						        	
						        	vector2[0] = Integer.parseInt(valor4);
						        	vector2[1] = Integer.parseInt(valor5);
						        	vector2[2] = Integer.parseInt(valor6);
						        							        	
						        	int numEscalar = Integer.parseInt(escalar_num);
						        	
						    		casilla_1_sal.setVisible(true);
						    		casilla_2_sal.setVisible(false);
						            casilla_3_sal.setVisible(false);
						            casilla_4_sal.setVisible(false);
						            casilla_5_sal.setVisible(false);
						            casilla_6_sal.setVisible(false);
						            casilla_7_sal.setVisible(false);
						            casilla_8_sal.setVisible(false);
						            casilla_9_sal.setVisible(false);	
						            casilla_10_sal.setVisible(false);	
						        	
						        	productoEscalar(vector1, vector2, numEscalar, spinnerValor);
	
					            
				        		}
				        		
					        	else {
									JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");						        		
					        	}
				        	}
				        	
				        	else {
				        		if(areAllFieldsFilled5x5()) {
					        		String valor1 = casilla_1_ent.getText();
						        	String valor2 = casilla_2_ent.getText();
						        	String valor3 = casilla_3_ent.getText();
						        	String valor4 = casilla_4_ent.getText();
						        	String valor5 = casilla_5_ent.getText();
						        	String valor6 = casilla_6_ent.getText();
						        	String valor7 = casilla_7_ent.getText();
						        	String valor8 = casilla_8_ent.getText();
						        	String valor9 = casilla_9_ent.getText();
						        	String valor10 = casilla_10_ent.getText();

						        	String escalar_num = num_escalar.getText();
						        	
						        	int[] vector1 = new int[5];
						        	int[] vector2 = new int[5];
						        	vector1[0] = Integer.parseInt(valor1);
						        	vector1[1] = Integer.parseInt(valor2);
						        	vector1[2] = Integer.parseInt(valor3);
						        	vector1[3] = Integer.parseInt(valor4);
						        	vector1[4] = Integer.parseInt(valor5);
						        	
						        	vector2[0] = Integer.parseInt(valor6);
						        	vector2[1] = Integer.parseInt(valor7);
						        	vector2[2] = Integer.parseInt(valor8);
						        	vector2[3] = Integer.parseInt(valor9);
						        	vector2[4] = Integer.parseInt(valor10);
						        							        	
						        	int numEscalar = Integer.parseInt(escalar_num);
						    		casilla_1_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_2_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_3_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_4_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_5_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_6_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_7_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_8_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_9_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_10_sal.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		
						    		casilla_1_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_2_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_3_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_4_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_5_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_6_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_7_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_8_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_9_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));
						    		casilla_10_ent.setFont(new Font("Roboto Medium", Font.PLAIN, 13));


						    		casilla_1_sal.setBounds(80, 9, 40, 40);
						    		casilla_1_sal.setVisible(true);
						            casilla_2_sal.setVisible(false);
						            casilla_3_sal.setVisible(false);
						            casilla_4_sal.setVisible(false);
						            casilla_5_sal.setVisible(false);
						            casilla_6_sal.setVisible(false);
						            casilla_7_sal.setVisible(false);
						            casilla_8_sal.setVisible(false);
						            casilla_9_sal.setVisible(false);
						            casilla_10_sal.setVisible(false);
		
						            
						        	productoEscalar(vector1, vector2, numEscalar, spinnerValor);
	
				        		}
				        		
					        	else {
									JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");						        		
					        	}
				        	}				        		
				        	
				        	
			
				    }
				    private boolean areAllFieldsFilled3X3() {
				        return !num_escalar.getText().isEmpty() &&
				        	   !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty();
				    }
				    
				    private boolean areAllFieldsFilled4X4() {
				        return !num_escalar.getText().isEmpty() &&
				        	   !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty() && 
				               !casilla_7_ent.getText().isEmpty() && 
				               !casilla_8_ent.getText().isEmpty();
				    }
				    
				    private boolean areAllFieldsFilled5x5() {
				        return !num_escalar.getText().isEmpty() &&
				        	   !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty() && 
				               !casilla_7_ent.getText().isEmpty() && 
				               !casilla_8_ent.getText().isEmpty() && 
				               !casilla_9_ent.getText().isEmpty() && 
				               !casilla_10_ent.getText().isEmpty();
				    }
				});
				
				mult_escalar_2.addMouseListener(new java.awt.event.MouseAdapter() {
		            @Override
		            public void mousePressed(MouseEvent e) {
		                // Acción al presionar el mouse
		            }

		            @Override
					public void mouseReleased(java.awt.event.MouseEvent evt) {
				        	if(spinnerValor == 3) {
				        		if(areAllFieldsFilled3X3()) {
					        		String valor1 = casilla_1_ent.getText();
						        	String valor2 = casilla_2_ent.getText();
						        	String valor3 = casilla_3_ent.getText();
						        	String valor4 = casilla_4_ent.getText();
						        	String valor5 = casilla_5_ent.getText();
						        	String valor6 = casilla_6_ent.getText();
		        	
						        	int[] vector1 = new int[3];
						        	int[] vector2 = new int[3];
						        	vector1[0] = Integer.parseInt(valor1);
						        	vector1[1] = Integer.parseInt(valor2);
						        	vector1[2] = Integer.parseInt(valor3);
						        	
						        	vector2[0] = Integer.parseInt(valor4);
						        	vector2[1] = Integer.parseInt(valor5);
						        	vector2[2] = Integer.parseInt(valor6);

						            casilla_1_sal.setBounds(80, 84, 70, 70);
						            casilla_2_sal.setBounds(168, 84, 70, 70);
						            casilla_3_sal.setBounds(256, 84, 70, 70);
						    		casilla_1_sal.setVisible(true);
						    		casilla_2_sal.setVisible(true);
						            casilla_3_sal.setVisible(true);
						            
						            casilla_4_sal.setVisible(false);
						            casilla_5_sal.setVisible(false);
						            casilla_6_sal.setVisible(false);
						            casilla_7_sal.setVisible(false);
						            casilla_8_sal.setVisible(false);
						            casilla_9_sal.setVisible(false);
						            casilla_10_sal.setVisible(false);

						        	productoVectorial(vector1, vector2);
						        					        			
				        		}
				        		
				        		else {
									JOptionPane.showMessageDialog(null, "Por favor, complete todas las casillas antes de continuar.");						        			
				        		}
				        	}
				        	else {
					        	JOptionPane.showMessageDialog(null, "El producto vectorial sólo se puede definir en tres dimensiones.");				        		
				        	}
				        	
				        	
			
				    }
				    private boolean areAllFieldsFilled3X3() {
				        return !casilla_1_ent.getText().isEmpty() && 
				               !casilla_2_ent.getText().isEmpty() && 
				               !casilla_3_ent.getText().isEmpty() && 
				               !casilla_4_ent.getText().isEmpty() && 
				               !casilla_5_ent.getText().isEmpty() && 
				               !casilla_6_ent.getText().isEmpty();
				    }
				    
				});
				
				
	}

	
	public void multEscalar(int vector1[], int vector2[], int escalar, int cantidad){
		int i = 0;
		
		for(i=0;i<cantidad;i++) {
			vector1[i] = vector1[i] * escalar;
			vector2[i] = vector2[i] * escalar;
		}
		
		if(cantidad == 3) {
	        casilla_1_sal.setText(String.valueOf(vector1[0]));
	        casilla_2_sal.setText(String.valueOf(vector1[1]));
	        casilla_3_sal.setText(String.valueOf(vector1[2]));
	        casilla_4_sal.setText(String.valueOf(vector2[0]));
	        casilla_5_sal.setText(String.valueOf(vector2[1]));
	        casilla_6_sal.setText(String.valueOf(vector2[2]));
		}
		
		else if(cantidad == 4) {
	        casilla_1_sal.setText(String.valueOf(vector1[0]));
	        casilla_2_sal.setText(String.valueOf(vector1[1]));
	        casilla_3_sal.setText(String.valueOf(vector1[2]));
	        casilla_4_sal.setText(String.valueOf(vector1[3]));
	        casilla_5_sal.setText(String.valueOf(vector2[0]));
	        casilla_6_sal.setText(String.valueOf(vector2[1]));
	        casilla_7_sal.setText(String.valueOf(vector2[2]));
	        casilla_8_sal.setText(String.valueOf(vector2[3]));			
		}
		
		else if(cantidad == 5) {
	        casilla_1_sal.setText(String.valueOf(vector1[0]));
	        casilla_2_sal.setText(String.valueOf(vector1[1]));
	        casilla_3_sal.setText(String.valueOf(vector1[2]));
	        casilla_4_sal.setText(String.valueOf(vector1[3]));
	        casilla_5_sal.setText(String.valueOf(vector1[4]));
	        casilla_6_sal.setText(String.valueOf(vector2[0]));
	        casilla_7_sal.setText(String.valueOf(vector2[1]));
	        casilla_8_sal.setText(String.valueOf(vector2[2]));
	        casilla_9_sal.setText(String.valueOf(vector2[3]));			
	        casilla_10_sal.setText(String.valueOf(vector2[4]));			
		}
	}
	
	public void vectorSuma(int vector1[], int vector2[], int cantidad) {
		
		int[] nuevoVector = new int[cantidad];
		int i = 0;
		
		for(i=0;i<cantidad;i++) {
			nuevoVector[i] = vector1[i] + vector2[i];
		}

		if(cantidad == 3) {
	        casilla_1_sal.setText(String.valueOf(nuevoVector[0]));
	        casilla_2_sal.setText(String.valueOf(nuevoVector[1]));
	        casilla_3_sal.setText(String.valueOf(nuevoVector[2]));
		}
		
		else if(cantidad == 4) {
	        casilla_1_sal.setText(String.valueOf(nuevoVector[0]));
	        casilla_2_sal.setText(String.valueOf(nuevoVector[1]));
	        casilla_3_sal.setText(String.valueOf(nuevoVector[2]));
	        casilla_4_sal.setText(String.valueOf(nuevoVector[3]));
		}
		
		else if(cantidad == 5) {
	        casilla_1_sal.setText(String.valueOf(nuevoVector[0]));
	        casilla_2_sal.setText(String.valueOf(nuevoVector[1]));
	        casilla_3_sal.setText(String.valueOf(nuevoVector[2]));
	        casilla_4_sal.setText(String.valueOf(nuevoVector[3]));
	        casilla_5_sal.setText(String.valueOf(nuevoVector[4]));		
		}
	}
	
	public void vectorResta(int vector1[], int vector2[], int cantidad) {
		
		int[] nuevoVector = new int[cantidad];
		int i = 0;
		
		for(i=0;i<cantidad;i++) {
			nuevoVector[i] = vector1[i] - vector2[i];
		}

		if(cantidad == 3) {
	        casilla_1_sal.setText(String.valueOf(nuevoVector[0]));
	        casilla_2_sal.setText(String.valueOf(nuevoVector[1]));
	        casilla_3_sal.setText(String.valueOf(nuevoVector[2]));
		}
		
		else if(cantidad == 4) {
	        casilla_1_sal.setText(String.valueOf(nuevoVector[0]));
	        casilla_2_sal.setText(String.valueOf(nuevoVector[1]));
	        casilla_3_sal.setText(String.valueOf(nuevoVector[2]));
	        casilla_4_sal.setText(String.valueOf(nuevoVector[3]));
		}
		
		else if(cantidad == 5) {
	        casilla_1_sal.setText(String.valueOf(nuevoVector[0]));
	        casilla_2_sal.setText(String.valueOf(nuevoVector[1]));
	        casilla_3_sal.setText(String.valueOf(nuevoVector[2]));
	        casilla_4_sal.setText(String.valueOf(nuevoVector[3]));
	        casilla_5_sal.setText(String.valueOf(nuevoVector[4]));		
		}
	}
	
	public void productoEscalar(int vector1[], int vector2[], int escalar, int cantidad) {
		int productoEscalar = 0;
		int i = 0;
		for(i = 0; i<cantidad; i++) {
			productoEscalar += vector1[i] * vector2[i];
		}
		
		casilla_1_sal.setBounds(172, 84, 70, 70);
		casilla_1_sal.setText(String.valueOf(productoEscalar));	
		
	}
	
	public void productoVectorial(int vector1[], int vector2[]) {
		int[] nuevoVector = new int[3];
        nuevoVector[0] = vector1[1] * vector2[2] - vector1[2] * vector2[1];
        nuevoVector[1] = vector1[2] * vector2[0] - vector1[0] * vector2[2];
        nuevoVector[2] = vector1[0] * vector2[1] - vector1[1] * vector2[0];		
		casilla_1_sal.setText(String.valueOf(nuevoVector[0]));
		casilla_2_sal.setText(String.valueOf(nuevoVector[1]));
		casilla_3_sal.setText(String.valueOf(nuevoVector[2]));		
	}
	
    private void abrirVentanaEstandar() {
	    this.dispose();
        Estandar Estandar= new Estandar(desktopPane);
        desktopPane.add(Estandar);
        Estandar.setVisible(true);
    }
    
	private void abrirVentanaEcuaciones() {
	    // Cerrar la ventana actual
	    this.dispose();

	    // Abrir Ventana2x2 en el mismo JDesktopPane
	    Ecuaciones2x2 ventana2x2 = new Ecuaciones2x2(desktopPane);
	    desktopPane.add(ventana2x2);
	    ventana2x2.setVisible(true);
	}
	
    private void abrirVentanaMatricesUno() {
	    this.dispose();
    	MatricesUno ventanaMatricesUno = new MatricesUno(desktopPane);
        desktopPane.add(ventanaMatricesUno);
        ventanaMatricesUno.setVisible(true);
        this.setVisible(false);
    }
}