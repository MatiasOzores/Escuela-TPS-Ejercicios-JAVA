import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class RoundedButtons extends BasicButtonUI {

    @Override
    public void paint(Graphics g, JComponent c) {
        JButton b = (JButton) c;
        Graphics2D g2 = (Graphics2D) g.create();
        
        // Enable anti-aliasing
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Create a rounded rectangle shape
        Shape shape = new RoundRectangle2D.Float(0, 0, b.getWidth(), b.getHeight(), 20, 20);

        // Paint the button background
        g2.setColor(b.getBackground());
        g2.fill(shape);

        // Paint the button border
        g2.setColor(b.getForeground());
        g2.draw(shape);

        // Draw the text
        FontMetrics fm = g2.getFontMetrics();
        Rectangle r = new Rectangle(0, 0, b.getWidth(), b.getHeight());
        Rectangle textRect = new Rectangle();
        textRect.x = r.x + (r.width - fm.stringWidth(b.getText())) / 2;
        textRect.y = r.y + ((r.height - fm.getHeight()) / 2) + fm.getAscent();

        g2.setColor(b.getForeground());
        g2.drawString(b.getText(), textRect.x, textRect.y);

        g2.dispose();
    }
}